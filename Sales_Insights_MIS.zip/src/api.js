const API_BASE = '/api';

function token() {
  return sessionStorage.getItem('si_token');
}

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const authToken = token();
  if (authToken) headers.Authorization = `Bearer ${authToken}`;
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const error = new Error(data?.message || `Request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

export const api = {
  login: (email, password) => request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  health: () => request('/health'),
  bootstrap: () => request('/bootstrap'),
  create: (resource, payload) => request(`/${resource}`, { method: 'POST', body: JSON.stringify(payload) }),
  update: (resource, id, payload) => request(`/${resource}/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  remove: (resource, id) => request(`/${resource}/${id}`, { method: 'DELETE' }),
  runEtl: () => request('/bi/etl', { method: 'POST', body: '{}' }),
  logImport: (payload) => request('/bi/import-log', { method: 'POST', body: JSON.stringify(payload) }),
  quality: () => request('/bi/quality'),
};
