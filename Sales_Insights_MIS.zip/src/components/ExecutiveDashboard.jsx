import React, { useMemo, useState } from 'react';
import { Bars, DashboardShell, KpiCard, SectionHeader, currency, exportCsv, saleProfit, saleRevenue } from './DashboardShell';

const navItems = [
  ['overview', 'Executive Overview', '▦'],
  ['regions', 'Regional Performance', '◎'],
  ['products', 'Product Performance', '□'],
  ['reports', 'Management Reports', '▤'],
];

export default function ExecutiveDashboard({ user, sales, products, onLogout }) {
  const [active, setActive] = useState('overview');
  const [region, setRegion] = useState('All');
  const [category, setCategory] = useState('All');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const filtered = useMemo(() => sales.filter((row) => (
    (region === 'All' || row.region === region) &&
    (category === 'All' || row.category === category) &&
    (!from || row.date >= from) && (!to || row.date <= to)
  )), [sales, region, category, from, to]);

  const revenue = filtered.reduce((s, r) => s + saleRevenue(r), 0);
  const profit = filtered.reduce((s, r) => s + saleProfit(r, products), 0);
  const units = filtered.reduce((s, r) => s + Number(r.quantity), 0);
  const margin = revenue ? (profit / revenue) * 100 : 0;

  const group = (field, metric) => Object.entries(filtered.reduce((acc, row) => {
    acc[row[field]] = (acc[row[field]] || 0) + metric(row);
    return acc;
  }, {})).sort((a, b) => b[1] - a[1]);

  const byRegion = group('region', saleRevenue);
  const byCategory = group('category', saleRevenue);
  const byProduct = group('product', saleRevenue);
  const byMonth = Object.entries(filtered.reduce((acc, row) => {
    const key = row.date.slice(0, 7);
    acc[key] = (acc[key] || 0) + saleRevenue(row);
    return acc;
  }, {})).sort((a, b) => a[0].localeCompare(b[0]));

  const reset = () => { setRegion('All'); setCategory('All'); setFrom(''); setTo(''); };
  const download = () => exportCsv('executive-management-report.csv',
    ['Date','Customer','Product','Category','Region','Quantity','Revenue','Profit','Salesperson'],
    filtered.map((r) => [r.date,r.customer,r.product,r.category,r.region,r.quantity,saleRevenue(r),saleProfit(r, products),r.salesperson]));

  const filterPanel = (
    <div className="report-filters panel no-print">
      <label>Region<select value={region} onChange={(e) => setRegion(e.target.value)}><option>All</option>{[...new Set(sales.map((s) => s.region))].sort().map((v) => <option key={v}>{v}</option>)}</select></label>
      <label>Category<select value={category} onChange={(e) => setCategory(e.target.value)}><option>All</option>{[...new Set(sales.map((s) => s.category))].sort().map((v) => <option key={v}>{v}</option>)}</select></label>
      <label>From<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
      <label>To<input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
      <button className="text-button reset" onClick={reset}>Reset</button>
    </div>
  );

  return (
    <DashboardShell user={user} title="Executive Dashboard" subtitle="Senior Management" navItems={navItems} active={active} setActive={setActive} onLogout={onLogout}>
      {active === 'overview' && <section>
        <SectionHeader eyebrow="Strategic intelligence" title="Company-wide performance" description="A read-only strategic view of revenue, estimated profit, units and sales concentration across the business." />
        {filterPanel}
        <div className="kpi-grid">
          <KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note={`${filtered.length} filtered transactions`} />
          <KpiCard icon="P" label="Estimated Profit" value={currency.format(profit)} note={`${margin.toFixed(1)}% estimated margin`} />
          <KpiCard icon="#" label="Units Sold" value={units.toLocaleString()} note="Company-wide selected period" />
          <KpiCard icon="R" label="Regions Active" value={new Set(filtered.map((r) => r.region)).size} note="Regions represented in results" />
        </div>
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Sales trend</h3><p>Revenue by month</p></div><span className="badge">Trend</span></div><Bars rows={byMonth} formatter={currency.format} /></article>
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Revenue by region</h3><p>Regional contribution</p></div><span className="badge">KES</span></div><Bars rows={byRegion} formatter={currency.format} secondary /></article>
        </div>
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Revenue by category</h3><p>Portfolio contribution</p></div></div><Bars rows={byCategory} formatter={currency.format} /></article>
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Top products</h3><p>Revenue contribution by product</p></div></div><Bars rows={byProduct.slice(0, 6)} formatter={currency.format} secondary /></article>
        </div>
      </section>}

      {active === 'regions' && <section>
        <SectionHeader eyebrow="Regional comparison" title="Regional performance" description="Compare revenue, profit, units and transaction volumes across company regions." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Region</th><th>Revenue</th><th>Profit</th><th>Units</th><th>Transactions</th><th>Revenue Share</th></tr></thead><tbody>
          {byRegion.map(([name, regRevenue]) => { const rows = filtered.filter((r) => r.region === name); const regProfit = rows.reduce((s,r) => s + saleProfit(r, products),0); const regUnits = rows.reduce((s,r) => s + Number(r.quantity),0); return <tr key={name}><td><strong>{name}</strong></td><td>{currency.format(regRevenue)}</td><td>{currency.format(regProfit)}</td><td>{regUnits}</td><td>{rows.length}</td><td>{revenue ? ((regRevenue/revenue)*100).toFixed(1) : 0}%</td></tr>; })}
        </tbody></table></div></div>
      </section>}

      {active === 'products' && <section>
        <SectionHeader eyebrow="Portfolio" title="Product performance" description="Review product revenue and estimated profitability without modifying operational records." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Revenue</th><th>Estimated Profit</th><th>Units</th><th>Transactions</th></tr></thead><tbody>
          {byProduct.map(([name, prodRevenue]) => { const rows = filtered.filter((r) => r.product === name); const prodProfit = rows.reduce((s,r) => s + saleProfit(r, products),0); const prodUnits = rows.reduce((s,r) => s + Number(r.quantity),0); return <tr key={name}><td><strong>{name}</strong></td><td>{rows[0]?.category}</td><td>{currency.format(prodRevenue)}</td><td>{currency.format(prodProfit)}</td><td>{prodUnits}</td><td>{rows.length}</td></tr>; })}
        </tbody></table></div></div>
      </section>}

      {active === 'reports' && <section className="print-area">
        <SectionHeader eyebrow="Executive reporting" title="Management report" description="Filter the dataset, export an Excel-compatible CSV, or print/save the report as PDF." action={<div className="button-row"><button className="secondary-button no-print" onClick={download}>Export Excel/CSV</button><button className="primary-button no-print" onClick={() => window.print()}>Print / Save PDF</button></div>} />
        {filterPanel}
        <div className="report-heading print-only"><h1>Sales Insights MIS</h1><p>Executive Management Report</p></div>
        <div className="kpi-grid report-kpis"><KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note={`${filtered.length} transactions`} /><KpiCard icon="P" label="Profit" value={currency.format(profit)} note={`${margin.toFixed(1)}% margin`} /><KpiCard icon="#" label="Units" value={units.toLocaleString()} note="Units sold" /><KpiCard icon="R" label="Regions" value={new Set(filtered.map(r => r.region)).size} note="Included in report" /></div>
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Region</th><th>Qty</th><th>Revenue</th><th>Profit</th></tr></thead><tbody>{filtered.map((r) => <tr key={r.id}><td>{r.date}</td><td>{r.customer}</td><td>{r.product}</td><td>{r.region}</td><td>{r.quantity}</td><td>{currency.format(saleRevenue(r))}</td><td>{currency.format(saleProfit(r, products))}</td></tr>)}</tbody></table></div></div>
        <p className="report-footer print-only">Generated {new Date().toLocaleString('en-KE')}</p>
      </section>}
    </DashboardShell>
  );
}
