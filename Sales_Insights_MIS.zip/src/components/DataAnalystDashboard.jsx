import React, { useMemo, useState } from 'react';
import { Bars, DashboardShell, KpiCard, SectionHeader, currency, exportCsv, nextId, saleRevenue } from './DashboardShell';
import { api } from '../api';

const navItems = [
  ['overview', 'BI Overview', '▦'],
  ['import', 'Import & ETL', '⇩'],
  ['quality', 'Data Quality', '✓'],
  ['datasets', 'Datasets', '▤'],
  ['analysis', 'Analysis', '⌁'],
  ['reports', 'Validation Reports', '□'],
];

function parseCsvLine(line) {
  const cells = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { current += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) {
      cells.push(current.trim()); current = '';
    } else current += char;
  }
  cells.push(current.trim());
  return cells;
}

function parseCsv(text) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter((line) => line.trim());
  if (lines.length < 2) return [];
  const headers = parseCsvLine(lines[0]).map((h) => h.trim().toLowerCase().replace(/\s+/g, ''));
  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  });
}

const normalize = (value) => String(value ?? '').trim();

export default function DataAnalystDashboard({ user, sales, setSales, products, setProducts, customers, setCustomers, refreshData, onLogout }) {
  const [active, setActive] = useState('overview');
  const [datasetType, setDatasetType] = useState('sales');
  const [message, setMessage] = useState('');
  const [etlRuns, setEtlRuns] = useState([]);
  const [datasetView, setDatasetView] = useState('sales');

  const quality = useMemo(() => {
    const saleKeys = new Map();
    let duplicates = 0;
    let invalidSales = 0;
    let missingSales = 0;
    sales.forEach((r) => {
      const key = [r.date,r.customer,r.product,r.region,r.quantity,r.unitPrice].map(normalize).join('|').toLowerCase();
      if (saleKeys.has(key)) duplicates += 1; else saleKeys.set(key, true);
      if (!r.date || !r.customer || !r.product || !r.region) missingSales += 1;
      if (!Number.isFinite(Number(r.quantity)) || Number(r.quantity) <= 0 || !Number.isFinite(Number(r.unitPrice)) || Number(r.unitPrice) < 0) invalidSales += 1;
    });
    const duplicateEmails = customers.length - new Set(customers.map((c) => normalize(c.email).toLowerCase())).size;
    const duplicateSkus = products.length - new Set(products.map((p) => normalize(p.sku).toLowerCase())).size;
    const issues = duplicates + invalidSales + missingSales + duplicateEmails + duplicateSkus;
    const total = sales.length + customers.length + products.length;
    const score = total ? Math.max(0, 100 - (issues / total) * 100) : 100;
    return { duplicates, invalidSales, missingSales, duplicateEmails, duplicateSkus, issues, score };
  }, [sales, customers, products]);

  const revenue = sales.reduce((s,r)=>s+saleRevenue(r),0);
  const units = sales.reduce((s,r)=>s+Number(r.quantity || 0),0);
  const byCategory = Object.entries(sales.reduce((acc,r)=>{ acc[r.category]=(acc[r.category]||0)+saleRevenue(r); return acc; },{})).sort((a,b)=>b[1]-a[1]);
  const byRegion = Object.entries(sales.reduce((acc,r)=>{ acc[r.region]=(acc[r.region]||0)+saleRevenue(r); return acc; },{})).sort((a,b)=>b[1]-a[1]);

  const logRun = (type, detail, status = 'Success') => setEtlRuns((prev) => [{ id: Date.now(), time: new Date().toLocaleString('en-KE'), type, detail, status }, ...prev].slice(0, 10));

  const importFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const rows = parseCsv(await file.text());
      if (!rows.length) throw new Error('The CSV contains no data rows.');
      if (datasetType === 'sales') {
        const mapped = rows.map((r, index) => ({
          id: nextId(sales) + index,
          date: r.date || r.saledate || '',
          customer: r.customer || r.customername || '',
          product: r.product || r.productname || '',
          category: r.category || 'Other',
          quantity: Number(r.quantity || r.qty || 0),
          unitPrice: Number(r.unitprice || r.price || 0),
          region: r.region || 'Other',
          salesperson: r.salesperson || r.representative || 'Imported',
        }));
        await setSales([...sales, ...mapped]);
      } else if (datasetType === 'products') {
        const mapped = rows.map((r, index) => ({
          id: nextId(products) + index,
          name: r.name || r.product || r.productname || '',
          category: r.category || 'Other',
          sku: r.sku || `IMP-${nextId(products)+index}`,
          price: Number(r.price || r.unitprice || 0),
          unitCost: Number(r.unitcost || r.cost || 0),
          stock: Number(r.stock || r.quantity || 0),
          status: r.status || 'Active',
        }));
        await setProducts([...products, ...mapped]);
      } else {
        const mapped = rows.map((r, index) => ({
          id: nextId(customers) + index,
          name: r.name || r.customer || r.customername || '',
          contact: r.contact || r.phone || '',
          email: r.email || '',
          region: r.region || 'Other',
          type: r.type || r.segment || 'Retailer',
        }));
        await setCustomers([...customers, ...mapped]);
      }
      await api.logImport({ fileName: file.name, datasetType, recordsReceived: rows.length, recordsImported: rows.length, recordsRejected: 0, status: 'Completed' });
      setMessage(`Imported ${rows.length} ${datasetType} rows into PostgreSQL from ${file.name}.`);
      logRun('Import', `${rows.length} ${datasetType} rows from ${file.name}`);
    } catch (error) {
      setMessage(`Import failed: ${error.message}`);
      logRun('Import', error.message, 'Failed');
    } finally {
      event.target.value = '';
    }
  };

  const runEtl = async () => {
    try {
      const result = await api.runEtl();
      await refreshData?.();
      setMessage(`ETL completed in PostgreSQL: ${result.recordsProcessed} master-data records standardized.`);
      logRun('ETL', `Server ETL standardized ${result.recordsProcessed} records`);
    } catch (error) {
      setMessage(`ETL failed: ${error.message}`);
      logRun('ETL', error.message, 'Failed');
    }
  };

  const removeDuplicateSales = () => {
    const seen = new Set();
    const deduped = sales.filter((r) => {
      const key = [r.date,r.customer,r.product,r.region,r.quantity,r.unitPrice].map(normalize).join('|').toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key); return true;
    });
    const removed = sales.length - deduped.length;
    setSales(deduped);
    setMessage(`${removed} duplicate sales row(s) removed.`);
    logRun('Data quality', `Removed ${removed} duplicate sales rows`);
  };

  const deleteRow = (type, id) => {
    if (!window.confirm('Delete this dataset row?')) return;
    if (type === 'sales') setSales(sales.filter((r)=>r.id!==id));
    if (type === 'products') setProducts(products.filter((r)=>r.id!==id));
    if (type === 'customers') setCustomers(customers.filter((r)=>r.id!==id));
  };

  const exportValidation = () => exportCsv('bi-validation-report.csv', ['Metric','Value'], [
    ['Sales rows',sales.length],['Product rows',products.length],['Customer rows',customers.length],['Revenue',revenue],['Units',units],['Duplicate sales',quality.duplicates],['Invalid sales',quality.invalidSales],['Missing sales fields',quality.missingSales],['Duplicate customer emails',quality.duplicateEmails],['Duplicate SKUs',quality.duplicateSkus],['Quality score',quality.score.toFixed(1)+'%']
  ]);

  return (
    <DashboardShell user={user} title="Data & BI Analyst Dashboard" subtitle="Data / BI Analyst" navItems={navItems} active={active} setActive={setActive} onLogout={onLogout}>
      {active === 'overview' && <section>
        <SectionHeader eyebrow="Data operations" title="Business intelligence overview" description="Monitor dataset health, validate dashboard totals and manage the analytical data pipeline." />
        <div className="kpi-grid"><KpiCard icon="Q" label="Data Quality Score" value={`${quality.score.toFixed(1)}%`} note={`${quality.issues} detected issue(s)`} /><KpiCard icon="S" label="Sales Rows" value={sales.length.toLocaleString()} note="Transactional dataset" /><KpiCard icon="M" label="Master Records" value={(products.length+customers.length).toLocaleString()} note="Products + customers" /><KpiCard icon="K" label="Verified Revenue" value={currency.format(revenue)} note="Recalculated from sales rows" /></div>
        <div className="dashboard-grid"><article className="panel chart-panel"><div className="panel-title"><div><h3>Revenue verification by category</h3><p>Independent aggregation from transactional rows</p></div></div><Bars rows={byCategory} formatter={currency.format} /></article><article className="panel chart-panel"><div className="panel-title"><div><h3>Revenue verification by region</h3><p>Cross-check dashboard regional totals</p></div></div><Bars rows={byRegion} formatter={currency.format} secondary /></article></div>
      </section>}

      {active === 'import' && <section>
        <SectionHeader eyebrow="Pipeline" title="Import and ETL management" description="Import CSV datasets, standardize fields and review recent pipeline activity." />
        {message && <div className="alert info">{message}</div>}
        <div className="dashboard-grid">
          <article className="panel upload-panel"><div className="panel-title"><div><h3>CSV data import</h3><p>Select the target dataset and upload an Excel-exported CSV file.</p></div></div><div className="upload-body"><label>Dataset type<select value={datasetType} onChange={(e)=>setDatasetType(e.target.value)}><option value="sales">Sales transactions</option><option value="products">Products</option><option value="customers">Customers</option></select></label><label className="file-drop">Choose CSV file<input type="file" accept=".csv,text/csv" onChange={importFile} /><span>CSV headers are mapped automatically for common field names.</span></label></div></article>
          <article className="panel"><div className="panel-title"><div><h3>ETL process</h3><p>Clean and standardize the PostgreSQL master datasets through the TypeORM service.</p></div></div><div className="etl-steps"><div><span>1</span><p><strong>Extract</strong>Use imported and stored PostgreSQL rows.</p></div><div><span>2</span><p><strong>Transform</strong>Trim text, normalize types, SKUs and emails.</p></div><div><span>3</span><p><strong>Load</strong>Write clean records back to PostgreSQL.</p></div><button className="primary-button" onClick={runEtl}>Run ETL now</button></div></article>
        </div>
        <article className="panel table-panel"><div className="panel-title"><div><h3>Recent pipeline runs</h3><p>Session activity log</p></div></div><div className="table-wrap"><table><thead><tr><th>Time</th><th>Process</th><th>Detail</th><th>Status</th></tr></thead><tbody>{etlRuns.length ? etlRuns.map((r)=><tr key={r.id}><td>{r.time}</td><td>{r.type}</td><td>{r.detail}</td><td><span className={`status ${r.status==='Success'?'active':'inactive'}`}>{r.status}</span></td></tr>) : <tr><td colSpan="4">No ETL activity in this session.</td></tr>}</tbody></table></div></article>
      </section>}

      {active === 'quality' && <section>
        <SectionHeader eyebrow="Validation" title="Data quality controls" description="Detect duplicate, missing and invalid records before figures are used for decision-making." action={<button className="secondary-button" onClick={removeDuplicateSales}>Remove duplicate sales</button>} />
        <div className="quality-grid"><div className="quality-card"><span>Duplicate sales</span><strong>{quality.duplicates}</strong><small>Exact business-key duplicates</small></div><div className="quality-card"><span>Invalid sales</span><strong>{quality.invalidSales}</strong><small>Invalid quantity or price</small></div><div className="quality-card"><span>Missing sales fields</span><strong>{quality.missingSales}</strong><small>Date/customer/product/region</small></div><div className="quality-card"><span>Duplicate emails</span><strong>{quality.duplicateEmails}</strong><small>Customer master data</small></div><div className="quality-card"><span>Duplicate SKUs</span><strong>{quality.duplicateSkus}</strong><small>Product master data</small></div></div>
        <div className="panel insight-panel"><h3>Quality interpretation</h3><p>The current quality score is <strong>{quality.score.toFixed(1)}%</strong>. Dashboard revenue is independently recalculated as quantity × unit price and currently equals <strong>{currency.format(revenue)}</strong>. Use Import & ETL to standardize new files before validating dashboards.</p></div>
      </section>}

      {active === 'datasets' && <section>
        <SectionHeader eyebrow="Master & transaction data" title="Dataset maintenance" description="Inspect source datasets and remove incorrect rows when required." action={<div className="tab-switch"><button className={datasetView==='sales'?'active':''} onClick={()=>setDatasetView('sales')}>Sales</button><button className={datasetView==='products'?'active':''} onClick={()=>setDatasetView('products')}>Products</button><button className={datasetView==='customers'?'active':''} onClick={()=>setDatasetView('customers')}>Customers</button></div>} />
        <div className="panel table-panel"><div className="table-wrap">
          {datasetView==='sales' && <table><thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Region</th><th>Qty</th><th>Revenue</th><th>Action</th></tr></thead><tbody>{sales.map((r)=><tr key={r.id}><td>{r.date}</td><td>{r.customer}</td><td>{r.product}</td><td>{r.region}</td><td>{r.quantity}</td><td>{currency.format(saleRevenue(r))}</td><td className="actions"><button className="danger" onClick={()=>deleteRow('sales',r.id)}>Delete</button></td></tr>)}</tbody></table>}
          {datasetView==='products' && <table><thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Cost</th><th>Stock</th><th>Action</th></tr></thead><tbody>{products.map((p)=><tr key={p.id}><td>{p.name}</td><td>{p.sku}</td><td>{p.category}</td><td>{currency.format(p.price)}</td><td>{currency.format(p.unitCost||0)}</td><td>{p.stock}</td><td className="actions"><button className="danger" onClick={()=>deleteRow('products',p.id)}>Delete</button></td></tr>)}</tbody></table>}
          {datasetView==='customers' && <table><thead><tr><th>Customer</th><th>Type</th><th>Region</th><th>Email</th><th>Contact</th><th>Action</th></tr></thead><tbody>{customers.map((c)=><tr key={c.id}><td>{c.name}</td><td>{c.type}</td><td>{c.region}</td><td>{c.email}</td><td>{c.contact}</td><td className="actions"><button className="danger" onClick={()=>deleteRow('customers',c.id)}>Delete</button></td></tr>)}</tbody></table>}
        </div></div>
      </section>}

      {active === 'analysis' && <section>
        <SectionHeader eyebrow="Descriptive analytics" title="Dataset analysis" description="Review descriptive measures calculated directly from the currently loaded sales data." />
        <div className="kpi-grid"><KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note="Sum(quantity × unit price)" /><KpiCard icon="#" label="Units" value={units.toLocaleString()} note="Total quantity" /><KpiCard icon="A" label="Avg Transaction" value={currency.format(sales.length ? revenue/sales.length : 0)} note="Revenue per sales row" /><KpiCard icon="P" label="Avg Unit Price" value={currency.format(units ? revenue/units : 0)} note="Weighted average selling price" /></div>
        <div className="dashboard-grid"><article className="panel chart-panel"><div className="panel-title"><div><h3>Category distribution</h3><p>Revenue concentration</p></div></div><Bars rows={byCategory} formatter={currency.format} /></article><article className="panel chart-panel"><div className="panel-title"><div><h3>Regional distribution</h3><p>Revenue concentration</p></div></div><Bars rows={byRegion} formatter={currency.format} secondary /></article></div>
      </section>}

      {active === 'reports' && <section className="print-area">
        <SectionHeader eyebrow="BI assurance" title="Dashboard validation report" description="Document row counts, quality checks and independently calculated MIS totals." action={<div className="button-row"><button className="secondary-button no-print" onClick={exportValidation}>Export Excel/CSV</button><button className="primary-button no-print" onClick={()=>window.print()}>Print / Save PDF</button></div>} />
        <div className="report-heading print-only"><h1>Sales Insights MIS</h1><p>Data & BI Validation Report</p></div>
        <div className="kpi-grid report-kpis"><KpiCard icon="Q" label="Quality Score" value={`${quality.score.toFixed(1)}%`} note={`${quality.issues} issues`} /><KpiCard icon="S" label="Sales Rows" value={sales.length} note="Transactions" /><KpiCard icon="K" label="Verified Revenue" value={currency.format(revenue)} note="Recalculated total" /><KpiCard icon="#" label="Verified Units" value={units.toLocaleString()} note="Recalculated quantity" /></div>
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Validation Check</th><th>Result</th><th>Interpretation</th></tr></thead><tbody><tr><td>Duplicate sales</td><td>{quality.duplicates}</td><td>{quality.duplicates ? 'Review or remove duplicates' : 'Passed'}</td></tr><tr><td>Invalid numeric sales fields</td><td>{quality.invalidSales}</td><td>{quality.invalidSales ? 'Requires correction' : 'Passed'}</td></tr><tr><td>Missing required sales fields</td><td>{quality.missingSales}</td><td>{quality.missingSales ? 'Requires completion' : 'Passed'}</td></tr><tr><td>Duplicate customer emails</td><td>{quality.duplicateEmails}</td><td>{quality.duplicateEmails ? 'Review customer master' : 'Passed'}</td></tr><tr><td>Duplicate product SKUs</td><td>{quality.duplicateSkus}</td><td>{quality.duplicateSkus ? 'Review product master' : 'Passed'}</td></tr></tbody></table></div></div>
        <p className="report-footer print-only">Generated {new Date().toLocaleString('en-KE')}</p>
      </section>}
    </DashboardShell>
  );
}
