import React, { useMemo, useState } from 'react';
import Modal from './Modal';
import { Bars, DashboardShell, KpiCard, SectionHeader, currency, exportCsv, nextId, saleRevenue } from './DashboardShell';

const navItems = [
  ['overview', 'Regional Overview', '▦'],
  ['sales', 'Sales Records', '↗'],
  ['products', 'Products', '□'],
  ['customers', 'Customers', '◎'],
  ['team', 'Sales Team', '♙'],
  ['reports', 'Regional Reports', '▤'],
];

export default function RegionalSalesDashboard({ user, sales, setSales, products, customers, onLogout }) {
  const [active, setActive] = useState('overview');
  const [modal, setModal] = useState(null);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const region = user.region || 'Nairobi';
  const target = Number(user.target || 50000);

  const regionalSales = useMemo(() => sales.filter((row) => row.region === region), [sales, region]);
  const regionalCustomers = useMemo(() => customers.filter((c) => c.region === region), [customers, region]);
  const revenue = regionalSales.reduce((s, r) => s + saleRevenue(r), 0);
  const units = regionalSales.reduce((s, r) => s + Number(r.quantity), 0);
  const attainment = target ? (revenue / target) * 100 : 0;

  const byProduct = Object.entries(regionalSales.reduce((acc, row) => { acc[row.product] = (acc[row.product] || 0) + saleRevenue(row); return acc; }, {})).sort((a,b) => b[1]-a[1]);
  const bySalesperson = Object.entries(regionalSales.reduce((acc, row) => { acc[row.salesperson] = (acc[row.salesperson] || 0) + saleRevenue(row); return acc; }, {})).sort((a,b) => b[1]-a[1]);
  const byCustomer = Object.entries(regionalSales.reduce((acc, row) => { acc[row.customer] = (acc[row.customer] || 0) + saleRevenue(row); return acc; }, {})).sort((a,b) => b[1]-a[1]);

  const filteredSales = regionalSales.filter((row) => Object.values(row).some((value) => String(value).toLowerCase().includes(search.toLowerCase())));

  const closeModal = () => { setModal(null); setEditing(null); };
  const saveSale = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const selectedProduct = products.find((p) => p.name === data.product);
    const selectedCustomer = customers.find((c) => c.name === data.customer);
    const item = {
      ...data,
      id: editing?.id ?? nextId(sales),
      quantity: Number(data.quantity),
      unitPrice: Number(data.unitPrice),
      category: selectedProduct?.category || 'Other',
      region,
      salesperson: data.salesperson || user.name,
      customer: selectedCustomer?.name || data.customer,
    };
    setSales(editing ? sales.map((row) => row.id === editing.id ? item : row) : [...sales, item]);
    closeModal();
  };

  const removeSale = (id) => {
    if (!window.confirm('Delete this regional sales record?')) return;
    setSales(sales.filter((row) => row.id !== id));
  };

  const exportReport = () => exportCsv(`regional-sales-${region}.csv`,
    ['Date','Customer','Product','Category','Region','Quantity','Unit Price','Revenue','Salesperson'],
    regionalSales.map((r) => [r.date,r.customer,r.product,r.category,r.region,r.quantity,r.unitPrice,saleRevenue(r),r.salesperson]));

  return (
    <DashboardShell user={user} title={`${region} Regional Sales Dashboard`} subtitle="Regional Sales Manager" navItems={navItems} active={active} setActive={setActive} onLogout={onLogout}
      actions={active === 'sales' ? <input className="search-box" placeholder="Search regional sales..." value={search} onChange={(e) => setSearch(e.target.value)} /> : null}>
      {active === 'overview' && <section>
        <SectionHeader eyebrow="Operational performance" title={`${region} sales performance`} description="Monitor regional revenue, target attainment, product demand, customers and sales representatives." />
        <div className="kpi-grid">
          <KpiCard icon="K" label="Regional Revenue" value={currency.format(revenue)} note={`${regionalSales.length} transactions`} />
          <KpiCard icon="T" label="Target Attainment" value={`${attainment.toFixed(1)}%`} note={`Target ${currency.format(target)}`} />
          <KpiCard icon="#" label="Units Sold" value={units.toLocaleString()} note="Across regional products" />
          <KpiCard icon="C" label="Regional Customers" value={regionalCustomers.length} note="Customer accounts in region" />
        </div>
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Product performance</h3><p>Revenue by product in your region</p></div></div><Bars rows={byProduct} formatter={currency.format} /></article>
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Sales representative performance</h3><p>Revenue contribution by representative</p></div></div><Bars rows={bySalesperson} formatter={currency.format} secondary /></article>
        </div>
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Customer contribution</h3><p>Highest-revenue customers</p></div></div><Bars rows={byCustomer} formatter={currency.format} /></article>
          <article className="panel"><div className="panel-title"><div><h3>Regional highlights</h3><p>Operational signals</p></div></div><div className="insight-list">
            <div><strong>Top product</strong><span>{byProduct[0]?.[0] || 'No sales yet'}</span></div>
            <div><strong>Lowest product</strong><span>{byProduct.length ? byProduct[byProduct.length - 1][0] : 'No sales yet'}</span></div>
            <div><strong>Top representative</strong><span>{bySalesperson[0]?.[0] || 'No sales yet'}</span></div>
            <div><strong>Target gap</strong><span>{currency.format(Math.max(0, target - revenue))}</span></div>
          </div></article>
        </div>
      </section>}

      {active === 'sales' && <section>
        <SectionHeader eyebrow="Regional transactions" title="Maintain regional sales" description={`Create, review, update and delete selected sales information for ${region} only.`} action={<button className="primary-button" onClick={() => { setEditing(null); setModal('sale'); }}>+ Record sale</button>} />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Revenue</th><th>Salesperson</th><th>Actions</th></tr></thead><tbody>
          {filteredSales.map((r) => <tr key={r.id}><td>{r.date}</td><td>{r.customer}</td><td>{r.product}</td><td>{r.quantity}</td><td>{currency.format(r.unitPrice)}</td><td><strong>{currency.format(saleRevenue(r))}</strong></td><td>{r.salesperson}</td><td className="actions"><button onClick={() => { setEditing(r); setModal('sale'); }}>Edit</button><button className="danger" onClick={() => removeSale(r.id)}>Delete</button></td></tr>)}
        </tbody></table></div></div>
      </section>}

      {active === 'products' && <section>
        <SectionHeader eyebrow="Product analysis" title="Regional product performance" description="Identify high- and low-performing products using regional sales activity." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Units Sold</th><th>Revenue</th><th>Position</th></tr></thead><tbody>
          {byProduct.map(([name, rev], index) => { const rows = regionalSales.filter((r) => r.product === name); return <tr key={name}><td><strong>{name}</strong></td><td>{rows[0]?.category}</td><td>{rows.reduce((s,r) => s + Number(r.quantity),0)}</td><td>{currency.format(rev)}</td><td><span className={`status ${index < Math.ceil(byProduct.length / 2) ? 'active' : 'inactive'}`}>{index < Math.ceil(byProduct.length / 2) ? 'High performing' : 'Needs attention'}</span></td></tr>; })}
        </tbody></table></div></div>
      </section>}

      {active === 'customers' && <section>
        <SectionHeader eyebrow="Accounts" title="Regional customers" description={`Customer accounts assigned to ${region}.`} />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Customer</th><th>Type</th><th>Contact</th><th>Email</th><th>Revenue</th></tr></thead><tbody>
          {regionalCustomers.map((c) => { const custRevenue = regionalSales.filter((r) => r.customer === c.name).reduce((s,r) => s + saleRevenue(r),0); return <tr key={c.id}><td><strong>{c.name}</strong></td><td>{c.type}</td><td>{c.contact}</td><td>{c.email}</td><td>{currency.format(custRevenue)}</td></tr>; })}
        </tbody></table></div></div>
      </section>}

      {active === 'team' && <section>
        <SectionHeader eyebrow="Sales representatives" title="Team performance" description="Compare sales representative contribution within the region." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Sales Representative</th><th>Transactions</th><th>Units</th><th>Revenue</th><th>Share</th></tr></thead><tbody>
          {bySalesperson.map(([name, repRevenue]) => { const rows = regionalSales.filter((r) => r.salesperson === name); return <tr key={name}><td><strong>{name}</strong></td><td>{rows.length}</td><td>{rows.reduce((s,r) => s + Number(r.quantity),0)}</td><td>{currency.format(repRevenue)}</td><td>{revenue ? ((repRevenue/revenue)*100).toFixed(1) : 0}%</td></tr>; })}
        </tbody></table></div></div>
      </section>}

      {active === 'reports' && <section className="print-area">
        <SectionHeader eyebrow="Regional reporting" title={`${region} sales report`} description="Generate a regional summary, export it for Excel, or print/save it as PDF." action={<div className="button-row"><button className="secondary-button no-print" onClick={exportReport}>Export Excel/CSV</button><button className="primary-button no-print" onClick={() => window.print()}>Print / Save PDF</button></div>} />
        <div className="report-heading print-only"><h1>Sales Insights MIS</h1><p>{region} Regional Sales Report</p></div>
        <div className="kpi-grid report-kpis"><KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note={`${regionalSales.length} transactions`} /><KpiCard icon="T" label="Target" value={currency.format(target)} note={`${attainment.toFixed(1)}% attained`} /><KpiCard icon="#" label="Units" value={units.toLocaleString()} note="Regional units sold" /><KpiCard icon="C" label="Customers" value={regionalCustomers.length} note="Regional accounts" /></div>
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Qty</th><th>Revenue</th><th>Salesperson</th></tr></thead><tbody>{regionalSales.map((r) => <tr key={r.id}><td>{r.date}</td><td>{r.customer}</td><td>{r.product}</td><td>{r.quantity}</td><td>{currency.format(saleRevenue(r))}</td><td>{r.salesperson}</td></tr>)}</tbody></table></div></div>
        <p className="report-footer print-only">Generated {new Date().toLocaleString('en-KE')}</p>
      </section>}

      {modal === 'sale' && <Modal title={editing ? 'Edit regional sale' : 'Record regional sale'} onClose={closeModal}><form className="form-grid" onSubmit={saveSale}>
        <label>Date<input name="date" type="date" defaultValue={editing?.date || new Date().toISOString().slice(0,10)} required /></label>
        <label>Customer<select name="customer" defaultValue={editing?.customer || regionalCustomers[0]?.name || customers[0]?.name || ''} required>{(regionalCustomers.length ? regionalCustomers : customers).map((c) => <option key={c.id}>{c.name}</option>)}</select></label>
        <label className="span-2">Product<select name="product" defaultValue={editing?.product || products[0]?.name || ''} required>{products.map((p) => <option key={p.id}>{p.name}</option>)}</select></label>
        <label>Quantity<input name="quantity" type="number" min="1" defaultValue={editing?.quantity || 1} required /></label>
        <label>Unit price (KES)<input name="unitPrice" type="number" min="0" step="0.01" defaultValue={editing?.unitPrice || products[0]?.price || ''} required /></label>
        <label className="span-2">Salesperson<input name="salesperson" defaultValue={editing?.salesperson || user.name} required /></label>
        <div className="form-actions span-2"><button type="button" className="secondary-button" onClick={closeModal}>Cancel</button><button className="primary-button">Save sale</button></div>
      </form></Modal>}
    </DashboardShell>
  );
}
