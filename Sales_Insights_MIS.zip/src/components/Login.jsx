import React, { useState } from 'react';
import AppIcon, { icons } from './AppIcon';

const demos = [
  ['Admin', 'admin@company.com', 'admin123'],
  ['Executive', 'executive@company.com', 'executive123'],
  ['Regional Manager', 'regional@company.com', 'regional123'],
  ['Marketing', 'marketing@company.com', 'marketing123'],
  ['Data / BI Analyst', 'analyst@company.com', 'analyst123'],
];

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('admin@company.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true); setError('');
    try { await onLogin(email.trim(), password); }
    catch (err) { setError(err.message || 'Unable to sign in. Make sure the API and PostgreSQL are running.'); }
    finally { setSubmitting(false); }
  };

  return (
    <main className="login-page">
      <section className="login-brand-panel">
        <div className="brand-mark"><AppIcon icon={icons.sparkle} /></div>
        <p className="eyebrow">Consumer Goods Intelligence</p>
        <h1>Sales Insights Management Information System</h1>
        <p className="login-lead">Turn operational sales data into clear decisions with role-based dashboards, live reporting and secure PostgreSQL-backed analytics.</p>
        <div className="login-feature-grid">
          <div><AppIcon icon={icons.shield} /><strong>Secure</strong><span>Role-based access and protected business data.</span></div>
          <div><AppIcon icon={icons.bolt} /><strong>Fast insights</strong><span>Live KPIs across revenue, regions and products.</span></div>
          <div><AppIcon icon={icons.layers} /><strong>Unified</strong><span>One workspace for every management role.</span></div>
        </div>
        
        
      </section>
      <section className="login-form-panel">
        <form className="login-card" onSubmit={submit}>
          <div><p className="eyebrow">Secure sign in</p><h2>Welcome back</h2></div>
          <label>Email address<div className="input-with-icon"><AppIcon icon={icons.email} /><input value={email} onChange={(e)=>setEmail(e.target.value)} type="email" required autoComplete="username" /></div></label>
          <label>Password<div className="input-with-icon"><AppIcon icon={icons.lock} /><input value={password} onChange={(e)=>setPassword(e.target.value)} type="password" required autoComplete="current-password" /></div></label>
          {error && <div className="alert error">{error}</div>}
          <button className="primary-button full" type="submit" disabled={submitting}>{submitting ? 'Signing in…' : <><span>Sign in</span><AppIcon icon={icons.arrowRight} /></>}</button>
          <div className="demo-accounts">{demos.map(([label, userEmail, userPassword]) => <button key={userEmail} type="button" onClick={()=>{setEmail(userEmail);setPassword(userPassword);}}>{label} — {userEmail} / {userPassword}</button>)}</div>
        </form>
      </section>
    </main>
  );
}
