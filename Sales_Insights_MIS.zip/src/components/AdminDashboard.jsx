import React, { useMemo, useState } from 'react';
import Modal from './Modal';
import AppIcon, { icons } from './AppIcon';

const currency = new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 });

const navItems = [
  ['overview', 'Overview', '▦'],
  ['products', 'Products', '□'],
  ['customers', 'Customers', '◎'],
  ['sales', 'Sales', '↗'],
  ['users', 'Users', '♙'],
  ['reports', 'Reports', '▤'],
];

function nextId(items) {
  return items.length ? Math.max(...items.map((item) => Number(item.id) || 0)) + 1 : 1;
}

function SectionHeader({ eyebrow, title, description, action }) {
  return (
    <div className="section-header">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2>{title}</h2>
        <p className="muted">{description}</p>
      </div>
      {action}
    </div>
  );
}

function KpiCard({ label, value, note, icon }) {
  return (
    <article className="kpi-card">
      <div className="kpi-icon"><AppIcon token={icon} /></div>
      <div>
        <p>{label}</p>
        <h3>{value}</h3>
        <span>{note}</span>
      </div>
    </article>
  );
}

function EmptyState({ text }) {
  return <div className="empty-state">{text}</div>;
}

export default function AdminDashboard({ user, users, setUsers, products, setProducts, customers, setCustomers, sales, setSales, onLogout }) {
  const [active, setActive] = useState('overview');
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(null);
  const [editing, setEditing] = useState(null);
  const [reportRegion, setReportRegion] = useState('All');
  const [reportCategory, setReportCategory] = useState('All');
  const [reportFrom, setReportFrom] = useState('');
  const [reportTo, setReportTo] = useState('');

  const totalRevenue = useMemo(() => sales.reduce((sum, row) => sum + Number(row.quantity) * Number(row.unitPrice), 0), [sales]);
  const totalUnits = useMemo(() => sales.reduce((sum, row) => sum + Number(row.quantity), 0), [sales]);
  const lowStock = useMemo(() => products.filter((p) => Number(p.stock) < 100), [products]);

  const revenueByCategory = useMemo(() => {
    const totals = {};
    sales.forEach((row) => {
      totals[row.category] = (totals[row.category] || 0) + Number(row.quantity) * Number(row.unitPrice);
    });
    return Object.entries(totals).sort((a, b) => b[1] - a[1]);
  }, [sales]);

  const revenueByRegion = useMemo(() => {
    const totals = {};
    sales.forEach((row) => {
      totals[row.region] = (totals[row.region] || 0) + Number(row.quantity) * Number(row.unitPrice);
    });
    return Object.entries(totals).sort((a, b) => b[1] - a[1]);
  }, [sales]);

  const reportRows = useMemo(() => {
    return sales.filter((row) => {
      const matchesRegion = reportRegion === 'All' || row.region === reportRegion;
      const matchesCategory = reportCategory === 'All' || row.category === reportCategory;
      const matchesFrom = !reportFrom || row.date >= reportFrom;
      const matchesTo = !reportTo || row.date <= reportTo;
      return matchesRegion && matchesCategory && matchesFrom && matchesTo;
    });
  }, [sales, reportRegion, reportCategory, reportFrom, reportTo]);

  const reportRevenue = reportRows.reduce((sum, row) => sum + Number(row.quantity) * Number(row.unitPrice), 0);
  const reportUnits = reportRows.reduce((sum, row) => sum + Number(row.quantity), 0);

  const filtered = (items, fields) => {
    const term = search.trim().toLowerCase();
    if (!term) return items;
    return items.filter((item) => fields.some((field) => String(item[field] ?? '').toLowerCase().includes(term)));
  };

  const openCreate = (type) => { setEditing(null); setModal(type); };
  const openEdit = (type, item) => { setEditing(item); setModal(type); };
  const closeModal = () => { setModal(null); setEditing(null); };

  const remove = (type, id) => {
    if (!window.confirm('Delete this record? This action cannot be undone.')) return;
    if (type === 'product') setProducts(products.filter((item) => item.id !== id));
    if (type === 'customer') setCustomers(customers.filter((item) => item.id !== id));
    if (type === 'sale') setSales(sales.filter((item) => item.id !== id));
    if (type === 'user') setUsers(users.filter((item) => item.id !== id));
  };

  const saveProduct = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const item = { ...data, id: editing?.id ?? nextId(products), price: Number(data.price), unitCost: Number(data.unitCost || 0), stock: Number(data.stock) };
    setProducts(editing ? products.map((p) => p.id === editing.id ? item : p) : [...products, item]);
    closeModal();
  };

  const saveCustomer = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const item = { ...data, id: editing?.id ?? nextId(customers) };
    setCustomers(editing ? customers.map((c) => c.id === editing.id ? item : c) : [...customers, item]);
    closeModal();
  };

  const saveSale = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const selectedProduct = products.find((p) => p.name === data.product);
    const selectedCustomer = customers.find((c) => c.name === data.customer);
    const item = {
      ...data,
      id: editing?.id ?? nextId(sales),
      quantity: Number(data.quantity),
      unitPrice: Number(data.unitPrice),
      category: selectedProduct?.category || data.category || 'Other',
      region: selectedCustomer?.region || data.region || 'Other',
    };
    setSales(editing ? sales.map((s) => s.id === editing.id ? item : s) : [...sales, item]);
    closeModal();
  };

  const saveUser = (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const item = { ...data, id: editing?.id ?? nextId(users) };
    setUsers(editing ? users.map((u) => u.id === editing.id ? item : u) : [...users, item]);
    closeModal();
  };

  const exportCsv = () => {
    const headers = ['Date', 'Customer', 'Product', 'Category', 'Region', 'Quantity', 'Unit Price', 'Revenue', 'Salesperson'];
    const rows = reportRows.map((row) => [
      row.date, row.customer, row.product, row.category, row.region, row.quantity, row.unitPrice,
      Number(row.quantity) * Number(row.unitPrice), row.salesperson,
    ]);
    const csv = [headers, ...rows].map((r) => r.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'sales-report.csv';
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const productMax = Math.max(1, ...revenueByCategory.map(([, value]) => value));
  const regionMax = Math.max(1, ...revenueByRegion.map(([, value]) => value));

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-mark small">SI</div>
          <div><strong>Sales Insights</strong><span>MIS Console</span></div>
        </div>

        <nav>
          {navItems.map(([key, label, icon]) => (
            <button key={key} className={active === key ? 'active' : ''} onClick={() => { setActive(key); setSearch(''); }}>
              <span><AppIcon token={icon} /></span>{label}
            </button>
          ))}
        </nav>

        <div className="sidebar-user">
          <div className="avatar">{user.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}</div>
          <div><strong>{user.name}</strong><span>Administrator</span></div>
          <button className="icon-button light" onClick={onLogout} title="Sign out"><AppIcon icon={icons.logout} /></button>
        </div>
      </aside>

      <main className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">Management Information System</p>
            <h1>Admin Dashboard</h1>
          </div>
          <div className="topbar-actions">
            {active !== 'overview' && active !== 'reports' && (
              <input className="search-box" placeholder={`Search ${active}...`} value={search} onChange={(e) => setSearch(e.target.value)} />
            )}
            <div className="date-pill"><AppIcon icon={icons.calendar} />{new Date().toLocaleDateString('en-KE', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
          </div>
        </header>

        <div className="content-area">
          {active === 'overview' && (
            <section>
              <SectionHeader eyebrow="Executive snapshot" title="Sales performance overview" description="A live summary based on sales, customer and product records stored in PostgreSQL." />
              <div className="kpi-grid">
                <KpiCard icon="K" label="Total Revenue" value={currency.format(totalRevenue)} note={`${sales.length} sales transactions`} />
                <KpiCard icon="#" label="Units Sold" value={totalUnits.toLocaleString()} note="Across all product categories" />
                <KpiCard icon="C" label="Customers" value={customers.length} note="Active account records" />
                <KpiCard icon="!" label="Low Stock Items" value={lowStock.length} note="Below 100 units available" />
              </div>

              <div className="dashboard-grid">
                <article className="panel chart-panel">
                  <div className="panel-title"><div><h3>Revenue by category</h3><p>Category contribution to recorded revenue</p></div><span className="badge">KES</span></div>
                  <div className="bar-chart">
                    {revenueByCategory.map(([label, value]) => (
                      <div className="bar-row" key={label}>
                        <div className="bar-label"><span>{label}</span><strong>{currency.format(value)}</strong></div>
                        <div className="bar-track"><div className="bar-fill" style={{ width: `${(value / productMax) * 100}%` }} /></div>
                      </div>
                    ))}
                  </div>
                </article>

                <article className="panel chart-panel">
                  <div className="panel-title"><div><h3>Revenue by region</h3><p>Regional distribution of sales revenue</p></div><span className="badge">Region</span></div>
                  <div className="bar-chart">
                    {revenueByRegion.map(([label, value]) => (
                      <div className="bar-row" key={label}>
                        <div className="bar-label"><span>{label}</span><strong>{currency.format(value)}</strong></div>
                        <div className="bar-track secondary"><div className="bar-fill" style={{ width: `${(value / regionMax) * 100}%` }} /></div>
                      </div>
                    ))}
                  </div>
                </article>
              </div>

              <div className="dashboard-grid bottom">
                <article className="panel">
                  <div className="panel-title"><div><h3>Recent sales</h3><p>Latest five recorded transactions</p></div><button className="text-button" onClick={() => setActive('sales')}>View all</button></div>
                  <div className="table-wrap compact">
                    <table><thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Revenue</th></tr></thead>
                    <tbody>{[...sales].sort((a,b) => b.date.localeCompare(a.date)).slice(0,5).map((row) => <tr key={row.id}><td>{row.date}</td><td>{row.customer}</td><td>{row.product}</td><td>{currency.format(row.quantity * row.unitPrice)}</td></tr>)}</tbody></table>
                  </div>
                </article>

                <article className="panel">
                  <div className="panel-title"><div><h3>Inventory attention</h3><p>Products approaching replenishment level</p></div><button className="text-button" onClick={() => setActive('products')}>Manage</button></div>
                  <div className="stock-list">
                    {lowStock.length ? lowStock.map((p) => <div key={p.id}><div><strong>{p.name}</strong><span>{p.sku} · {p.category}</span></div><span className="stock-pill">{p.stock} units</span></div>) : <EmptyState text="No low-stock products." />}
                  </div>
                </article>
              </div>
            </section>
          )}

          {active === 'products' && (
            <section>
              <SectionHeader eyebrow="Master data" title="Product management" description="Create, review, update and delete products used in sales records." action={<button className="primary-button" onClick={() => openCreate('product')}>+ Add product</button>} />
              <div className="panel table-panel"><div className="table-wrap"><table>
                <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Unit Price</th><th>Unit Cost</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>{filtered(products, ['name','sku','category','status']).map((p) => <tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.sku}</td><td>{p.category}</td><td>{currency.format(p.price)}</td><td>{currency.format(p.unitCost || 0)}</td><td>{p.stock}</td><td><span className="status active">{p.status}</span></td><td className="actions"><button onClick={() => openEdit('product',p)}>Edit</button><button className="danger" onClick={() => remove('product',p.id)}>Delete</button></td></tr>)}</tbody>
              </table></div></div>
            </section>
          )}

          {active === 'customers' && (
            <section>
              <SectionHeader eyebrow="Customer records" title="Customer management" description="Maintain retailers, wholesalers and distributor account information." action={<button className="primary-button" onClick={() => openCreate('customer')}>+ Add customer</button>} />
              <div className="panel table-panel"><div className="table-wrap"><table>
                <thead><tr><th>Customer</th><th>Type</th><th>Region</th><th>Contact</th><th>Email</th><th>Actions</th></tr></thead>
                <tbody>{filtered(customers, ['name','type','region','contact','email']).map((c) => <tr key={c.id}><td><strong>{c.name}</strong></td><td>{c.type}</td><td>{c.region}</td><td>{c.contact}</td><td>{c.email}</td><td className="actions"><button onClick={() => openEdit('customer',c)}>Edit</button><button className="danger" onClick={() => remove('customer',c.id)}>Delete</button></td></tr>)}</tbody>
              </table></div></div>
            </section>
          )}

          {active === 'sales' && (
            <section>
              <SectionHeader eyebrow="Transactions" title="Sales records" description="Record and manage consumer goods sales transactions." action={<button className="primary-button" onClick={() => openCreate('sale')}>+ Record sale</button>} />
              <div className="panel table-panel"><div className="table-wrap"><table>
                <thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Region</th><th>Qty</th><th>Unit Price</th><th>Revenue</th><th>Actions</th></tr></thead>
                <tbody>{filtered(sales, ['date','customer','product','region','salesperson']).map((s) => <tr key={s.id}><td>{s.date}</td><td>{s.customer}</td><td>{s.product}</td><td>{s.region}</td><td>{s.quantity}</td><td>{currency.format(s.unitPrice)}</td><td><strong>{currency.format(s.quantity*s.unitPrice)}</strong></td><td className="actions"><button onClick={() => openEdit('sale',s)}>Edit</button><button className="danger" onClick={() => remove('sale',s.id)}>Delete</button></td></tr>)}</tbody>
              </table></div></div>
            </section>
          )}

          {active === 'users' && (
            <section>
              <SectionHeader eyebrow="Access control" title="User management" description="Create users, assign roles and maintain dashboard access." action={<button className="primary-button" onClick={() => openCreate('user')}>+ Add user</button>} />
              <div className="panel table-panel"><div className="table-wrap"><table>
                <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Region</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>{filtered(users, ['name','email','role','region','status']).map((u) => <tr key={u.id}><td><strong>{u.name}</strong></td><td>{u.email}</td><td className="capitalize">{u.role}</td><td>{u.region || '—'}</td><td><span className={`status ${u.status === 'Active' ? 'active' : 'inactive'}`}>{u.status}</span></td><td className="actions"><button onClick={() => openEdit('user',u)}>Edit</button>{u.id !== user.id && <button className="danger" onClick={() => remove('user',u.id)}>Delete</button>}</td></tr>)}</tbody>
              </table></div></div>
            </section>
          )}

          {active === 'reports' && (
            <section className="print-area">
              <SectionHeader eyebrow="Management reporting" title="Sales summary report" description="Filter transactions, review KPIs, print the report or export the current result set to CSV." action={<div className="button-row"><button className="secondary-button no-print" onClick={exportCsv}>Export CSV</button><button className="primary-button no-print" onClick={() => window.print()}>Print report</button></div>} />

              <div className="report-filters panel no-print">
                <label>Region<select value={reportRegion} onChange={(e) => setReportRegion(e.target.value)}><option>All</option>{[...new Set(sales.map((s) => s.region))].sort().map((v) => <option key={v}>{v}</option>)}</select></label>
                <label>Category<select value={reportCategory} onChange={(e) => setReportCategory(e.target.value)}><option>All</option>{[...new Set(sales.map((s) => s.category))].sort().map((v) => <option key={v}>{v}</option>)}</select></label>
                <label>From<input type="date" value={reportFrom} onChange={(e) => setReportFrom(e.target.value)} /></label>
                <label>To<input type="date" value={reportTo} onChange={(e) => setReportTo(e.target.value)} /></label>
                <button className="text-button reset" onClick={() => { setReportRegion('All'); setReportCategory('All'); setReportFrom(''); setReportTo(''); }}>Reset filters</button>
              </div>

              <div className="report-heading print-only"><h1>Sales Insights MIS</h1><p>Management Sales Summary Report</p></div>
              <div className="kpi-grid report-kpis">
                <KpiCard icon="K" label="Filtered Revenue" value={currency.format(reportRevenue)} note={`${reportRows.length} transactions`} />
                <KpiCard icon="#" label="Filtered Units" value={reportUnits.toLocaleString()} note="Units sold in selection" />
                <KpiCard icon="A" label="Average Transaction" value={currency.format(reportRows.length ? reportRevenue/reportRows.length : 0)} note="Revenue per transaction" />
                <KpiCard icon="R" label="Regions Covered" value={new Set(reportRows.map((r) => r.region)).size} note="Regions in selection" />
              </div>

              <div className="panel table-panel"><div className="table-wrap"><table>
                <thead><tr><th>Date</th><th>Customer</th><th>Product</th><th>Category</th><th>Region</th><th>Qty</th><th>Revenue</th><th>Salesperson</th></tr></thead>
                <tbody>{reportRows.length ? reportRows.map((s) => <tr key={s.id}><td>{s.date}</td><td>{s.customer}</td><td>{s.product}</td><td>{s.category}</td><td>{s.region}</td><td>{s.quantity}</td><td>{currency.format(s.quantity*s.unitPrice)}</td><td>{s.salesperson}</td></tr>) : <tr><td colSpan="8"><EmptyState text="No sales match the current report filters." /></td></tr>}</tbody>
              </table></div></div>
              <p className="report-footer print-only">Generated on {new Date().toLocaleString('en-KE')}</p>
            </section>
          )}
        </div>
      </main>

      {modal === 'product' && <Modal title={editing ? 'Edit product' : 'Add product'} onClose={closeModal}><form className="form-grid" onSubmit={saveProduct}>
        <label className="span-2">Product name<input name="name" defaultValue={editing?.name || ''} required /></label>
        <label>SKU<input name="sku" defaultValue={editing?.sku || ''} required /></label>
        <label>Category<input name="category" defaultValue={editing?.category || ''} required /></label>
        <label>Unit price (KES)<input name="price" type="number" min="0" step="0.01" defaultValue={editing?.price || ''} required /></label>
        <label>Unit cost (KES)<input name="unitCost" type="number" min="0" step="0.01" defaultValue={editing?.unitCost || ''} /></label>
        <label>Stock quantity<input name="stock" type="number" min="0" defaultValue={editing?.stock || ''} required /></label>
        <label>Status<select name="status" defaultValue={editing?.status || 'Active'}><option>Active</option><option>Inactive</option></select></label>
        <div className="form-actions span-2"><button type="button" className="secondary-button" onClick={closeModal}>Cancel</button><button className="primary-button">Save product</button></div>
      </form></Modal>}

      {modal === 'customer' && <Modal title={editing ? 'Edit customer' : 'Add customer'} onClose={closeModal}><form className="form-grid" onSubmit={saveCustomer}>
        <label className="span-2">Customer name<input name="name" defaultValue={editing?.name || ''} required /></label>
        <label>Type<select name="type" defaultValue={editing?.type || 'Retailer'}><option>Retailer</option><option>Wholesaler</option><option>Distributor</option></select></label>
        <label>Region<input name="region" defaultValue={editing?.region || ''} required /></label>
        <label>Contact<input name="contact" defaultValue={editing?.contact || ''} required /></label>
        <label>Email<input name="email" type="email" defaultValue={editing?.email || ''} required /></label>
        <div className="form-actions span-2"><button type="button" className="secondary-button" onClick={closeModal}>Cancel</button><button className="primary-button">Save customer</button></div>
      </form></Modal>}

      {modal === 'sale' && <Modal title={editing ? 'Edit sale' : 'Record sale'} onClose={closeModal}><form className="form-grid" onSubmit={saveSale}>
        <label>Date<input name="date" type="date" defaultValue={editing?.date || new Date().toISOString().slice(0,10)} required /></label>
        <label>Customer<select name="customer" defaultValue={editing?.customer || customers[0]?.name || ''} required>{customers.map((c) => <option key={c.id}>{c.name}</option>)}</select></label>
        <label className="span-2">Product<select name="product" defaultValue={editing?.product || products[0]?.name || ''} required>{products.map((p) => <option key={p.id}>{p.name}</option>)}</select></label>
        <label>Quantity<input name="quantity" type="number" min="1" defaultValue={editing?.quantity || 1} required /></label>
        <label>Unit price (KES)<input name="unitPrice" type="number" min="0" step="0.01" defaultValue={editing?.unitPrice || products[0]?.price || ''} required /></label>
        <label className="span-2">Salesperson<input name="salesperson" defaultValue={editing?.salesperson || user.name} required /></label>
        <div className="form-actions span-2"><button type="button" className="secondary-button" onClick={closeModal}>Cancel</button><button className="primary-button">Save sale</button></div>
      </form></Modal>}

      {modal === 'user' && <Modal title={editing ? 'Edit user' : 'Add user'} onClose={closeModal}><form className="form-grid" onSubmit={saveUser}>
        <label className="span-2">Full name<input name="name" defaultValue={editing?.name || ''} required /></label>
        <label className="span-2">Email<input name="email" type="email" defaultValue={editing?.email || ''} required /></label>
        <label>Role<select name="role" defaultValue={editing?.role || 'executive'}><option value="admin">System Administrator</option><option value="executive">Executive / Senior Management</option><option value="regional_manager">Regional Sales Manager</option><option value="marketing">Marketing Analyst / Manager</option><option value="analyst">Data / BI Analyst</option></select></label>
        <label>Status<select name="status" defaultValue={editing?.status || 'Active'}><option>Active</option><option>Inactive</option></select></label>
        <label>Assigned region<input name="region" defaultValue={editing?.region || ''} placeholder="Required for regional managers" /></label>
        <label>Sales target (KES)<input name="target" type="number" min="0" step="0.01" defaultValue={editing?.target || ''} placeholder="Optional" /></label>
        <label className="span-2">Password<input name="password" type="password" defaultValue="" required={!editing} placeholder={editing ? "Leave blank to keep current password" : "Enter initial password"} /></label>
        <div className="form-actions span-2"><button type="button" className="secondary-button" onClick={closeModal}>Cancel</button><button className="primary-button">Save user</button></div>
      </form></Modal>}
    </div>
  );
}
