import React from 'react';
import AppIcon, { icons } from './AppIcon';

export function DashboardShell({ user, title, subtitle, navItems, active, setActive, onLogout, children, actions }) {
  const initials = user.name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase();
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <div className="brand-mark small">SI</div>
          <div><strong>Sales Insights</strong><span>MIS Console</span></div>
        </div>
        <nav>
          {navItems.map(([key, label, icon]) => (
            <button key={key} className={active === key ? 'active' : ''} onClick={() => setActive(key)}>
              <span><AppIcon token={icon} /></span>{label}
            </button>
          ))}
        </nav>
        <div className="sidebar-user">
          <div className="avatar">{initials}</div>
          <div><strong>{user.name}</strong><span>{subtitle}</span></div>
          <button className="icon-button light" onClick={onLogout} title="Sign out"><AppIcon icon={icons.logout} /></button>
        </div>
      </aside>
      <main className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">Management Information System</p>
            <h1>{title}</h1>
          </div>
          <div className="topbar-actions">
            {actions}
            <div className="date-pill"><AppIcon icon={icons.calendar} />{new Date().toLocaleDateString('en-KE', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
          </div>
        </header>
        <div className="content-area">{children}</div>
      </main>
    </div>
  );
}

export function SectionHeader({ eyebrow, title, description, action }) {
  return (
    <div className="section-header">
      <div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2><p className="muted">{description}</p></div>
      {action}
    </div>
  );
}

export function KpiCard({ label, value, note, icon }) {
  return (
    <article className="kpi-card">
      <div className="kpi-icon"><AppIcon token={icon} /></div>
      <div><p>{label}</p><h3>{value}</h3><span>{note}</span></div>
    </article>
  );
}

export function Bars({ rows, formatter = (v) => v, secondary = false }) {
  const max = Math.max(1, ...rows.map(([, value]) => Number(value) || 0));
  return (
    <div className="bar-chart">
      {rows.map(([label, value]) => (
        <div className="bar-row" key={label}>
          <div className="bar-label"><span>{label}</span><strong>{formatter(value)}</strong></div>
          <div className={`bar-track ${secondary ? 'secondary' : ''}`}><div className="bar-fill" style={{ width: `${Math.max(2, (Number(value) / max) * 100)}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

export const currency = new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 });
export const number = new Intl.NumberFormat('en-KE');

export function getProductCost(product, fallbackPrice = 0) {
  return Number(product?.unitCost ?? product?.cost ?? Number(fallbackPrice) * 0.7);
}

export function saleRevenue(row) {
  return Number(row.quantity || 0) * Number(row.unitPrice || 0);
}

export function saleProfit(row, products) {
  const product = products.find((p) => p.name === row.product);
  return saleRevenue(row) - Number(row.quantity || 0) * getProductCost(product, row.unitPrice);
}

export function exportCsv(filename, headers, rows) {
  const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function nextId(items) {
  return items.length ? Math.max(...items.map((item) => Number(item.id) || 0)) + 1 : 1;
}
