import React from 'react';

export default function RolePlaceholder({ user, onLogout }) {
  return (
    <main className="placeholder-page">
      <section className="placeholder-card">
        <div className="brand-mark">SI</div>
        <p className="eyebrow">Role access confirmed</p>
        <h1>{user.role === 'manager' ? 'Sales Manager' : 'Sales Representative'} Dashboard</h1>
        <p>
          Hello {user.name}. Your login has been recognized correctly as <strong>{user.role}</strong>. This dashboard is intentionally left as the next development stage while the Admin dashboard is being tested first.
        </p>
        <button className="primary-button" onClick={onLogout}>Sign out</button>
      </section>
    </main>
  );
}
