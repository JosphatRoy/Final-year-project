import React, { useMemo, useState } from 'react';
import { Bars, DashboardShell, KpiCard, SectionHeader, currency, exportCsv, getProductCost, saleRevenue } from './DashboardShell';

const navItems = [
  ['overview', 'Marketing Overview', '▦'],
  ['customers', 'Customer Segments', '◎'],
  ['products', 'Product & Category', '□'],
  ['regions', 'Regional Demand', '⌖'],
  ['promotions', 'Promotions', '%'],
  ['reports', 'Marketing Reports', '▤'],
];

const promotions = [
  { id: 1, name: 'Back-to-School Dairy Push', category: 'Dairy', channel: 'Retail displays', spend: 18000, attributedRevenue: 42000, uplift: 18 },
  { id: 2, name: 'Family Cooking Bundle', category: 'Food', channel: 'Distributor bundle', spend: 25000, attributedRevenue: 61500, uplift: 24 },
  { id: 3, name: 'Refresh & Win', category: 'Beverages', channel: 'Social + retail', spend: 22000, attributedRevenue: 53200, uplift: 21 },
  { id: 4, name: 'Clean Home Week', category: 'Home Care', channel: 'Retail discount', spend: 15000, attributedRevenue: 33750, uplift: 13 },
];

export default function MarketingDashboard({ user, sales, products, customers, onLogout }) {
  const [active, setActive] = useState('overview');
  const [region, setRegion] = useState('All');
  const [category, setCategory] = useState('All');
  const [aFrom, setAFrom] = useState('2026-09-01');
  const [aTo, setATo] = useState('2026-09-09');
  const [bFrom, setBFrom] = useState('2026-09-10');
  const [bTo, setBTo] = useState('2026-09-30');

  const filtered = useMemo(() => sales.filter((r) => (region === 'All' || r.region === region) && (category === 'All' || r.category === category)), [sales, region, category]);
  const revenue = filtered.reduce((s,r) => s + saleRevenue(r),0);
  const units = filtered.reduce((s,r) => s + Number(r.quantity),0);

  const byField = (field, source = filtered) => Object.entries(source.reduce((acc,row) => { acc[row[field]] = (acc[row[field]] || 0) + saleRevenue(row); return acc; },{})).sort((a,b)=>b[1]-a[1]);
  const byCategory = byField('category');
  const byRegion = byField('region');

  const customerSegments = Object.entries(customers.reduce((acc,c) => {
    const value = filtered.filter((r) => r.customer === c.name).reduce((s,r) => s + saleRevenue(r),0);
    acc[c.type] = (acc[c.type] || 0) + value;
    return acc;
  },{})).sort((a,b)=>b[1]-a[1]);

  const productMargins = products.map((p) => {
    const rows = filtered.filter((r) => r.product === p.name);
    const prodRevenue = rows.reduce((s,r) => s + saleRevenue(r),0);
    const cost = rows.reduce((s,r) => s + Number(r.quantity) * getProductCost(p, r.unitPrice),0);
    const profit = prodRevenue - cost;
    return { ...p, revenue: prodRevenue, profit, margin: prodRevenue ? (profit/prodRevenue)*100 : 0, units: rows.reduce((s,r)=>s+Number(r.quantity),0) };
  }).sort((a,b)=>b.margin-a.margin);

  const periodRevenue = (from,to) => filtered.filter((r) => (!from || r.date >= from) && (!to || r.date <= to)).reduce((s,r)=>s+saleRevenue(r),0);
  const revenueA = periodRevenue(aFrom,aTo);
  const revenueB = periodRevenue(bFrom,bTo);
  const periodChange = revenueA ? ((revenueB-revenueA)/revenueA)*100 : 0;

  const exportReport = () => exportCsv('marketing-analysis-report.csv',
    ['Product','Category','Revenue','Estimated Profit','Margin %','Units'],
    productMargins.map((p) => [p.name,p.category,p.revenue,p.profit,p.margin.toFixed(2),p.units]));

  return (
    <DashboardShell user={user} title="Marketing Analytics Dashboard" subtitle="Marketing Analyst / Manager" navItems={navItems} active={active} setActive={setActive} onLogout={onLogout}>
      {active === 'overview' && <section>
        <SectionHeader eyebrow="Market intelligence" title="Marketing performance overview" description="Analyze customer segments, product demand, regional demand, margin signals and period-to-period performance." />
        <div className="report-filters panel">
          <label>Region<select value={region} onChange={(e)=>setRegion(e.target.value)}><option>All</option>{[...new Set(sales.map(s=>s.region))].sort().map(v=><option key={v}>{v}</option>)}</select></label>
          <label>Category<select value={category} onChange={(e)=>setCategory(e.target.value)}><option>All</option>{[...new Set(sales.map(s=>s.category))].sort().map(v=><option key={v}>{v}</option>)}</select></label>
          <div className="filter-note"><strong>{filtered.length}</strong><span>matching transactions</span></div>
        </div>
        <div className="kpi-grid">
          <KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note="Selected marketing view" />
          <KpiCard icon="#" label="Units" value={units.toLocaleString()} note="Demand volume" />
          <KpiCard icon="C" label="Customer Segments" value={customerSegments.filter(([,v])=>v>0).length} note="Active segment types" />
          <KpiCard icon="M" label="Highest Margin Product" value={`${productMargins[0]?.margin.toFixed(1) || 0}%`} note={productMargins[0]?.name || 'No product'} />
        </div>
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Category demand</h3><p>Revenue by category</p></div></div><Bars rows={byCategory} formatter={currency.format} /></article>
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Regional demand</h3><p>Revenue by region</p></div></div><Bars rows={byRegion} formatter={currency.format} secondary /></article>
        </div>
        <article className="panel compare-panel">
          <div className="panel-title"><div><h3>Period comparison</h3><p>Compare revenue between two marketing periods</p></div><span className={`trend-pill ${periodChange >= 0 ? 'positive' : 'negative'}`}>{periodChange >= 0 ? '+' : ''}{periodChange.toFixed(1)}%</span></div>
          <div className="period-grid"><div><h4>Period A</h4><div className="mini-filter"><input type="date" value={aFrom} onChange={(e)=>setAFrom(e.target.value)} /><input type="date" value={aTo} onChange={(e)=>setATo(e.target.value)} /></div><strong>{currency.format(revenueA)}</strong></div><div><h4>Period B</h4><div className="mini-filter"><input type="date" value={bFrom} onChange={(e)=>setBFrom(e.target.value)} /><input type="date" value={bTo} onChange={(e)=>setBTo(e.target.value)} /></div><strong>{currency.format(revenueB)}</strong></div></div>
        </article>
      </section>}

      {active === 'customers' && <section>
        <SectionHeader eyebrow="Segmentation" title="Customer segment analysis" description="Understand which customer types contribute the most revenue and demand." />
        <div className="dashboard-grid">
          <article className="panel chart-panel"><div className="panel-title"><div><h3>Revenue by customer type</h3><p>Retailer, wholesaler and distributor contribution</p></div></div><Bars rows={customerSegments} formatter={currency.format} /></article>
          <article className="panel table-panel"><div className="panel-title"><div><h3>Customer detail</h3><p>Revenue contribution by account</p></div></div><div className="table-wrap"><table><thead><tr><th>Customer</th><th>Segment</th><th>Region</th><th>Revenue</th></tr></thead><tbody>{customers.map((c)=>{ const rev=filtered.filter(r=>r.customer===c.name).reduce((s,r)=>s+saleRevenue(r),0); return <tr key={c.id}><td><strong>{c.name}</strong></td><td>{c.type}</td><td>{c.region}</td><td>{currency.format(rev)}</td></tr>;})}</tbody></table></div></article>
        </div>
      </section>}

      {active === 'products' && <section>
        <SectionHeader eyebrow="Portfolio analysis" title="Products, categories and margins" description="Identify high-margin products and compare revenue, demand and estimated profitability." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Units</th><th>Revenue</th><th>Est. Profit</th><th>Margin</th></tr></thead><tbody>{productMargins.map((p)=><tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.category}</td><td>{p.units}</td><td>{currency.format(p.revenue)}</td><td>{currency.format(p.profit)}</td><td><span className={`status ${p.margin >= 25 ? 'active' : 'inactive'}`}>{p.margin.toFixed(1)}%</span></td></tr>)}</tbody></table></div></div>
      </section>}

      {active === 'regions' && <section>
        <SectionHeader eyebrow="Geographic demand" title="Regional market demand" description="Compare where product demand and revenue are strongest across the market." />
        <div className="panel chart-panel"><div className="panel-title"><div><h3>Revenue by region</h3><p>Regional demand intensity</p></div></div><Bars rows={byRegion} formatter={currency.format} /></div>
      </section>}

      {active === 'promotions' && <section>
        <SectionHeader eyebrow="Campaign analysis" title="Promotional performance" description="Compare promotional spend, attributed revenue, revenue uplift and estimated return on marketing spend." />
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Campaign</th><th>Category</th><th>Channel</th><th>Spend</th><th>Attributed Revenue</th><th>Uplift</th><th>ROAS</th></tr></thead><tbody>{promotions.map((p)=><tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.category}</td><td>{p.channel}</td><td>{currency.format(p.spend)}</td><td>{currency.format(p.attributedRevenue)}</td><td>{p.uplift}%</td><td>{(p.attributedRevenue/p.spend).toFixed(2)}x</td></tr>)}</tbody></table></div></div>
      </section>}

      {active === 'reports' && <section className="print-area">
        <SectionHeader eyebrow="Marketing reporting" title="Marketing analytical report" description="Export analytical product results or print/save the current report as PDF." action={<div className="button-row"><button className="secondary-button no-print" onClick={exportReport}>Export Excel/CSV</button><button className="primary-button no-print" onClick={()=>window.print()}>Print / Save PDF</button></div>} />
        <div className="report-heading print-only"><h1>Sales Insights MIS</h1><p>Marketing Analytical Report</p></div>
        <div className="kpi-grid report-kpis"><KpiCard icon="K" label="Revenue" value={currency.format(revenue)} note={`${filtered.length} transactions`} /><KpiCard icon="#" label="Units" value={units.toLocaleString()} note="Units sold" /><KpiCard icon="S" label="Segments" value={customerSegments.length} note="Customer types" /><KpiCard icon="P" label="Promotions" value={promotions.length} note="Campaigns assessed" /></div>
        <div className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Revenue</th><th>Estimated Profit</th><th>Margin</th><th>Units</th></tr></thead><tbody>{productMargins.map((p)=><tr key={p.id}><td>{p.name}</td><td>{p.category}</td><td>{currency.format(p.revenue)}</td><td>{currency.format(p.profit)}</td><td>{p.margin.toFixed(1)}%</td><td>{p.units}</td></tr>)}</tbody></table></div></div>
        <p className="report-footer print-only">Generated {new Date().toLocaleString('en-KE')}</p>
      </section>}
    </DashboardShell>
  );
}
