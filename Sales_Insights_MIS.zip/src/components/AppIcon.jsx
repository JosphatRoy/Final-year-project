import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faChartPie, faBox, faUsers, faArrowTrendUp, faUserGear, faFileLines,
  faDownload, faCircleCheck, faDatabase, faChartLine, faLocationDot,
  faPercent, faMoneyBillTrendUp, faBoxesStacked, faUserGroup, faTriangleExclamation,
  faBullseye, faCoins, faGaugeHigh, faRightFromBracket, faMagnifyingGlass,
  faCalendarDays, faShieldHalved, faBolt, faLayerGroup, faServer,
  faArrowRight, faKey, faEnvelope, faLock
} from '@fortawesome/free-solid-svg-icons';

const byToken = {
  '▦': faChartPie, '□': faBox, '◎': faUsers, '↗': faArrowTrendUp, '♙': faUserGear,
  '▤': faFileLines, '⇩': faDownload, '✓': faCircleCheck, '⌁': faChartLine,
  '⌖': faLocationDot, '%': faPercent, K: faMoneyBillTrendUp, '#': faBoxesStacked,
  C: faUserGroup, '!': faTriangleExclamation, T: faBullseye, P: faCoins,
  R: faLocationDot, Q: faGaugeHigh, S: faDatabase, M: faChartLine, A: faChartPie,
};

export const icons = {
  logout: faRightFromBracket, search: faMagnifyingGlass, calendar: faCalendarDays,
  shield: faShieldHalved, bolt: faBolt, layers: faLayerGroup, server: faServer,
  arrowRight: faArrowRight, key: faKey, email: faEnvelope,
  lock: faLock, sparkle: faChartLine,
};

export default function AppIcon({ token, icon, className = '' }) {
  const resolved = icon || byToken[token] || faChartPie;
  return <FontAwesomeIcon icon={resolved} className={className} aria-hidden="true" />;
}
