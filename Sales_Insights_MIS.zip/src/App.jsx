import React, { useCallback, useEffect, useState } from 'react';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import ExecutiveDashboard from './components/ExecutiveDashboard';
import RegionalSalesDashboard from './components/RegionalSalesDashboard';
import MarketingDashboard from './components/MarketingDashboard';
import DataAnalystDashboard from './components/DataAnalystDashboard';
import RolePlaceholder from './components/RolePlaceholder';
import { api } from './api';

function getStoredSession() {
  try {
    const raw = sessionStorage.getItem('si_session_v2');
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function jsonComparable(value) {
  const copy = { ...value };
  delete copy.password;
  return JSON.stringify(copy);
}

export default function App() {
  const [users, setUsersState] = useState([]);
  const [products, setProductsState] = useState([]);
  const [customers, setCustomersState] = useState([]);
  const [sales, setSalesState] = useState([]);
  const [session, setSession] = useState(getStoredSession);
  const [loading, setLoading] = useState(Boolean(getStoredSession()));
  const [dataError, setDataError] = useState('');

  const logout = useCallback(() => {
    sessionStorage.removeItem('si_token');
    sessionStorage.removeItem('si_session_v2');
    sessionStorage.removeItem('si_session');
    setSession(null);
    setUsersState([]); setProductsState([]); setCustomersState([]); setSalesState([]);
  }, []);

  const refreshData = useCallback(async () => {
    if (!sessionStorage.getItem('si_token')) return;
    const data = await api.bootstrap();
    setUsersState(data.users || []);
    setProductsState(data.products || []);
    setCustomersState(data.customers || []);
    setSalesState(data.sales || []);
    setDataError('');
  }, []);

  useEffect(() => {
    if (!session) { setLoading(false); return; }
    setLoading(true);
    refreshData().catch((error) => {
      if (error.status === 401) logout();
      else setDataError(error.message);
    }).finally(() => setLoading(false));
  }, [session, refreshData, logout]);

  const login = async (email, password) => {
    const result = await api.login(email, password);
    sessionStorage.setItem('si_token', result.token);
    sessionStorage.setItem('si_session_v2', JSON.stringify(result.user));
    sessionStorage.removeItem('si_session');
    setSession(result.user);
  };

  const persistCollection = useCallback(async (resource, before, setState, nextOrUpdater) => {
    const next = typeof nextOrUpdater === 'function' ? nextOrUpdater(before) : nextOrUpdater;
    setState(next);
    try {
      const beforeById = new Map(before.map((item) => [String(item.id), item]));
      const nextById = new Map(next.filter((item) => item.id != null).map((item) => [String(item.id), item]));
      const removed = before.filter((item) => !nextById.has(String(item.id)));
      const added = next.filter((item) => item.id == null || !beforeById.has(String(item.id)));
      const updated = next.filter((item) => item.id != null && beforeById.has(String(item.id)) && (Boolean(item.password) || jsonComparable(beforeById.get(String(item.id))) !== jsonComparable(item)));

      for (const item of removed) await api.remove(resource, item.id);
      for (const item of updated) await api.update(resource, item.id, item);
      for (const item of added) await api.create(resource, item);
      await refreshData();
    } catch (error) {
      await refreshData().catch(() => {});
      window.alert(error.message || 'The database operation failed.');
    }
  }, [refreshData]);

  const setUsers = useCallback((next) => persistCollection('users', users, setUsersState, next), [users, persistCollection]);
  const setProducts = useCallback((next) => persistCollection('products', products, setProductsState, next), [products, persistCollection]);
  const setCustomers = useCallback((next) => persistCollection('customers', customers, setCustomersState, next), [customers, persistCollection]);
  const setSales = useCallback((next) => persistCollection('sales', sales, setSalesState, next), [sales, persistCollection]);

  if (!session) return <Login onLogin={login} />;
  if (loading) return <main className="login-page"><section className="login-form-panel"><div className="login-card"><h2>Connecting to PostgreSQL…</h2><p className="muted">Loading your role-based MIS data through the Express API.</p></div></section></main>;

  const common = { user: session, sales, products, customers, onLogout: logout };
  const errorBanner = dataError ? <div className="alert error" style={{margin:'12px'}}>{dataError}</div> : null;

  let dashboard;
  if (session.role === 'admin') dashboard = <AdminDashboard {...common} users={users} setUsers={setUsers} setProducts={setProducts} setCustomers={setCustomers} setSales={setSales} />;
  else if (session.role === 'executive') dashboard = <ExecutiveDashboard {...common} />;
  else if (session.role === 'regional_manager') dashboard = <RegionalSalesDashboard {...common} setSales={setSales} />;
  else if (session.role === 'marketing') dashboard = <MarketingDashboard {...common} />;
  else if (session.role === 'analyst') dashboard = <DataAnalystDashboard {...common} setSales={setSales} setProducts={setProducts} setCustomers={setCustomers} refreshData={refreshData} />;
  else dashboard = <RolePlaceholder user={session} onLogout={logout} />;

  return <>{errorBanner}{dashboard}</>;
}
