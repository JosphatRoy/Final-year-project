# TypeORM + SQL Integration Notes

This build extends the existing Tailwind Sales Insights MIS without replacing the working frontend.

## Integrated database features

- TypeORM entities and repositories for operational CRUD.
- TypeORM migration-first startup (`synchronize: false`).
- PostgreSQL direct SQL for analytics and reporting.
- Added customer codes and customer segmentation tables.
- Added promotion-to-product and promotion-to-sale attribution tables.
- Added regional profit targets.
- Extended import metadata for source type, completion time and errors.
- Added SQL-backed analytics endpoints while preserving regional-manager data scoping.
- Existing authentication, dashboards, Tailwind UI and one-command `npm run dev` startup remain intact.

## New migration

`server/database/migrations/1790812800000-AnalyticsAndMarketingSchema.js`

It runs automatically when the backend starts.

## Main analytics endpoints

- `/api/analytics/overview`
- `/api/analytics/regions`
- `/api/analytics/products`
- `/api/analytics/monthly`
- `/api/analytics/customers`
- `/api/marketing/segments`
- `/api/marketing/promotions`

All endpoints after login require the existing JWT token.
