import { AppDataSource } from '../database/data-source.js';

export async function audit(req, action, tableName, recordId, oldValues = null, newValues = null) {
  try {
    const repo = AppDataSource.getRepository('AuditLog');
    await repo.save(repo.create({
      user: req.user?.id ? { id: req.user.id } : null,
      action,
      tableName,
      recordId: recordId == null ? null : String(recordId),
      oldValues,
      newValues,
      ipAddress: req.ip,
    }));
  } catch (error) {
    console.error('Audit log failed:', error.message);
  }
}
