import { AppDataSource } from '../database/data-source.js';

export async function ensureRegion(name) {
  const clean = String(name || 'Other').trim() || 'Other';
  const repo = AppDataSource.getRepository('Region');
  let row = await repo.findOne({ where: { name: clean } });
  if (!row) row = await repo.save(repo.create({ name: clean }));
  return row;
}

export async function ensureCategory(name) {
  const clean = String(name || 'Other').trim() || 'Other';
  const repo = AppDataSource.getRepository('Category');
  let row = await repo.findOne({ where: { name: clean } });
  if (!row) row = await repo.save(repo.create({ name: clean }));
  return row;
}

export async function ensureRepresentative(name, region) {
  const clean = String(name || 'Unassigned').trim() || 'Unassigned';
  const repo = AppDataSource.getRepository('SalesRepresentative');
  let row = await repo.findOne({ where: { name: clean, region: { id: region.id } }, relations: { region: true } });
  if (!row) row = await repo.save(repo.create({ name: clean, region, status: 'Active' }));
  return row;
}
