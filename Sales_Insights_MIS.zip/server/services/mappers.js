export function productDto(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category?.name || '',
    sku: row.sku,
    price: Number(row.sellingPrice),
    unitCost: Number(row.costPrice),
    stock: Number(row.stock),
    status: row.status,
  };
}

export function customerDto(row) {
  return {
    id: row.id,
    code: row.code || '',
    name: row.name,
    contact: row.phone || '',
    email: row.email || '',
    region: row.region?.name || '',
    type: row.segment || 'Retailer',
    status: row.status,
  };
}

export function userDto(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role?.code || '',
    status: row.isActive ? 'Active' : 'Inactive',
    region: row.region?.name || '',
    target: row.target == null ? null : Number(row.target),
  };
}

export function saleDto(order) {
  const item = order.items?.[0];
  return {
    id: order.id,
    date: typeof order.saleDate === 'string' ? order.saleDate : order.saleDate?.toISOString?.().slice(0, 10),
    customer: order.customer?.name || '',
    product: item?.product?.name || '',
    category: item?.product?.category?.name || '',
    quantity: Number(item?.quantity || 0),
    unitPrice: Number(item?.unitPrice || 0),
    region: order.region?.name || '',
    salesperson: order.representative?.name || '',
  };
}
