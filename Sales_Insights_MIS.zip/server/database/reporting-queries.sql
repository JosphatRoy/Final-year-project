-- Revenue and profit by region
SELECT r.region_name,
       SUM(o.total_amount) AS revenue,
       SUM(o.profit) AS profit
FROM sales_orders o
JOIN regions r ON r.region_id = o.region_id
GROUP BY r.region_name
ORDER BY revenue DESC;

-- Product performance
SELECT p.product_name,
       c.category_name,
       SUM(i.quantity) AS units_sold,
       SUM(i.line_total) AS revenue,
       SUM(i.profit) AS profit
FROM sales_order_items i
JOIN products p ON p.product_id = i.product_id
JOIN categories c ON c.category_id = p.category_id
GROUP BY p.product_name, c.category_name
ORDER BY revenue DESC;

-- Monthly sales trend
SELECT DATE_TRUNC('month', o.sale_date) AS month,
       SUM(o.total_amount) AS revenue,
       SUM(o.profit) AS profit
FROM sales_orders o
GROUP BY DATE_TRUNC('month', o.sale_date)
ORDER BY month;

-- Customer performance
SELECT c.customer_name,
       r.region_name,
       COUNT(o.order_id) AS orders,
       SUM(o.total_amount) AS revenue
FROM sales_orders o
JOIN customers c ON c.customer_id = o.customer_id
JOIN regions r ON r.region_id = o.region_id
GROUP BY c.customer_name, r.region_name
ORDER BY revenue DESC;


-- Customer segmentation performance
SELECT cs.segment_name,
       COUNT(DISTINCT csm.customer_id) AS customers,
       COALESCE(SUM(o.total_amount), 0) AS revenue
FROM customer_segments cs
LEFT JOIN customer_segment_members csm ON csm.segment_id = cs.segment_id
LEFT JOIN sales_orders o ON o.customer_id = csm.customer_id
GROUP BY cs.segment_name
ORDER BY revenue DESC;

-- Promotion performance
SELECT p.promotion_name,
       p.start_date,
       p.end_date,
       COUNT(DISTINCT pp.product_id) AS promoted_products,
       COUNT(DISTINCT ps.order_id) AS attributed_orders,
       COALESCE(SUM(ps.discount_given), 0) AS discount_given,
       COALESCE(SUM(o.total_amount), 0) AS attributed_revenue
FROM promotions p
LEFT JOIN promotion_products pp ON pp.promotion_id = p.promotion_id
LEFT JOIN promotion_sales ps ON ps.promotion_id = p.promotion_id
LEFT JOIN sales_orders o ON o.order_id = ps.order_id
GROUP BY p.promotion_id, p.promotion_name, p.start_date, p.end_date
ORDER BY p.start_date DESC;

-- Target attainment by region
SELECT r.region_name,
       t.target_month,
       t.revenue_target,
       t.profit_target,
       COALESCE(SUM(o.total_amount), 0) AS actual_revenue,
       COALESCE(SUM(o.profit), 0) AS actual_profit
FROM sales_targets t
JOIN regions r ON r.region_id = t.region_id
LEFT JOIN sales_orders o
  ON o.region_id = t.region_id
 AND DATE_TRUNC('month', o.sale_date) = DATE_TRUNC('month', t.target_month)
GROUP BY r.region_name, t.target_month, t.revenue_target, t.profit_target
ORDER BY t.target_month DESC, r.region_name;
