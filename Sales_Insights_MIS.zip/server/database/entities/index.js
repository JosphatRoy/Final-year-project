import { EntitySchema } from 'typeorm';

export const Role = new EntitySchema({
  name: 'Role', tableName: 'roles',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'role_id' },
    code: { type: String, length: 50, unique: true, name: 'role_code' },
    name: { type: String, length: 120, unique: true, name: 'role_name' },
    description: { type: 'text', nullable: true },
  },
  relations: { users: { type: 'one-to-many', target: 'User', inverseSide: 'role' } },
});

export const Region = new EntitySchema({
  name: 'Region', tableName: 'regions',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'region_id' },
    name: { type: String, length: 100, unique: true, name: 'region_name' },
    description: { type: 'text', nullable: true },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
});

export const Category = new EntitySchema({
  name: 'Category', tableName: 'categories',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'category_id' },
    name: { type: String, length: 100, unique: true, name: 'category_name' },
    description: { type: 'text', nullable: true },
  },
});

export const User = new EntitySchema({
  name: 'User', tableName: 'users',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'user_id' },
    name: { type: String, length: 150, name: 'full_name' },
    email: { type: String, length: 150, unique: true },
    passwordHash: { type: String, name: 'password_hash' },
    isActive: { type: Boolean, default: true, name: 'is_active' },
    target: { type: 'decimal', precision: 14, scale: 2, nullable: true, name: 'sales_target' },
    lastLogin: { type: 'timestamp', nullable: true, name: 'last_login' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
    updatedAt: { type: 'timestamp', updateDate: true, name: 'updated_at' },
  },
  relations: {
    role: { type: 'many-to-one', target: 'Role', joinColumn: { name: 'role_id' }, nullable: false, onDelete: 'RESTRICT' },
    region: { type: 'many-to-one', target: 'Region', joinColumn: { name: 'region_id' }, nullable: true, onDelete: 'SET NULL' },
  },
});

export const Product = new EntitySchema({
  name: 'Product', tableName: 'products',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'product_id' },
    sku: { type: String, length: 50, unique: true },
    name: { type: String, length: 150, name: 'product_name' },
    costPrice: { type: 'decimal', precision: 12, scale: 2, name: 'cost_price' },
    sellingPrice: { type: 'decimal', precision: 12, scale: 2, name: 'selling_price' },
    stock: { type: Number, default: 0 },
    status: { type: String, length: 30, default: 'Active' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
    updatedAt: { type: 'timestamp', updateDate: true, name: 'updated_at' },
  },
  relations: {
    category: { type: 'many-to-one', target: 'Category', joinColumn: { name: 'category_id' }, nullable: false, onDelete: 'RESTRICT' },
    promotionLinks: { type: 'one-to-many', target: 'PromotionProduct', inverseSide: 'product' },
  },
});

export const Customer = new EntitySchema({
  name: 'Customer', tableName: 'customers',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'customer_id' },
    code: { type: String, length: 50, unique: true, nullable: true, name: 'customer_code' },
    name: { type: String, length: 150, name: 'customer_name' },
    segment: { type: String, length: 50, nullable: true },
    city: { type: String, length: 100, nullable: true },
    phone: { type: String, length: 50, nullable: true },
    email: { type: String, length: 150, nullable: true },
    status: { type: String, length: 30, default: 'Active' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
    updatedAt: { type: 'timestamp', updateDate: true, name: 'updated_at' },
  },
  relations: {
    region: { type: 'many-to-one', target: 'Region', joinColumn: { name: 'region_id' }, nullable: true, onDelete: 'SET NULL' },
    segmentMemberships: { type: 'one-to-many', target: 'CustomerSegmentMember', inverseSide: 'customer' },
  },
});

export const SalesRepresentative = new EntitySchema({
  name: 'SalesRepresentative', tableName: 'sales_representatives',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'rep_id' },
    employeeNumber: { type: String, length: 50, unique: true, nullable: true, name: 'employee_number' },
    name: { type: String, length: 150, name: 'rep_name' },
    status: { type: String, length: 30, default: 'Active' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    user: { type: 'many-to-one', target: 'User', joinColumn: { name: 'user_id' }, nullable: true, onDelete: 'SET NULL' },
    region: { type: 'many-to-one', target: 'Region', joinColumn: { name: 'region_id' }, nullable: false, onDelete: 'RESTRICT' },
  },
});

export const Promotion = new EntitySchema({
  name: 'Promotion', tableName: 'promotions',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'promotion_id' },
    name: { type: String, length: 150, name: 'promotion_name' },
    startDate: { type: 'date', name: 'start_date' },
    endDate: { type: 'date', name: 'end_date' },
    discountPercentage: { type: 'decimal', precision: 5, scale: 2, nullable: true, name: 'discount_percentage' },
    budget: { type: 'decimal', precision: 14, scale: 2, nullable: true },
    description: { type: 'text', nullable: true },
    status: { type: String, length: 30, default: 'Planned' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    productLinks: { type: 'one-to-many', target: 'PromotionProduct', inverseSide: 'promotion' },
    saleLinks: { type: 'one-to-many', target: 'PromotionSale', inverseSide: 'promotion' },
  },
});

export const SalesOrder = new EntitySchema({
  name: 'SalesOrder', tableName: 'sales_orders',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'order_id' },
    invoiceNumber: { type: String, length: 50, unique: true, name: 'invoice_number' },
    saleDate: { type: 'date', name: 'sale_date' },
    totalAmount: { type: 'decimal', precision: 14, scale: 2, default: 0, name: 'total_amount' },
    totalCost: { type: 'decimal', precision: 14, scale: 2, default: 0, name: 'total_cost' },
    profit: { type: 'decimal', precision: 14, scale: 2, default: 0 },
    paymentStatus: { type: String, length: 30, default: 'Paid', name: 'payment_status' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
    updatedAt: { type: 'timestamp', updateDate: true, name: 'updated_at' },
  },
  relations: {
    customer: { type: 'many-to-one', target: 'Customer', joinColumn: { name: 'customer_id' }, nullable: false, onDelete: 'RESTRICT' },
    representative: { type: 'many-to-one', target: 'SalesRepresentative', joinColumn: { name: 'rep_id' }, nullable: true, onDelete: 'SET NULL' },
    region: { type: 'many-to-one', target: 'Region', joinColumn: { name: 'region_id' }, nullable: false, onDelete: 'RESTRICT' },
    promotion: { type: 'many-to-one', target: 'Promotion', joinColumn: { name: 'promotion_id' }, nullable: true, onDelete: 'SET NULL' },
    createdBy: { type: 'many-to-one', target: 'User', joinColumn: { name: 'created_by' }, nullable: true, onDelete: 'SET NULL' },
    items: { type: 'one-to-many', target: 'SalesOrderItem', inverseSide: 'order', cascade: true },
  },
});

export const SalesOrderItem = new EntitySchema({
  name: 'SalesOrderItem', tableName: 'sales_order_items',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'item_id' },
    quantity: { type: Number },
    unitPrice: { type: 'decimal', precision: 12, scale: 2, name: 'unit_price' },
    unitCost: { type: 'decimal', precision: 12, scale: 2, name: 'unit_cost' },
    discountAmount: { type: 'decimal', precision: 12, scale: 2, default: 0, name: 'discount_amount' },
    lineTotal: { type: 'decimal', precision: 14, scale: 2, name: 'line_total' },
    costAmount: { type: 'decimal', precision: 14, scale: 2, name: 'cost_amount' },
    profit: { type: 'decimal', precision: 14, scale: 2 },
  },
  relations: {
    order: { type: 'many-to-one', target: 'SalesOrder', inverseSide: 'items', joinColumn: { name: 'order_id' }, nullable: false, onDelete: 'CASCADE' },
    product: { type: 'many-to-one', target: 'Product', joinColumn: { name: 'product_id' }, nullable: false, onDelete: 'RESTRICT' },
  },
});

export const SalesTarget = new EntitySchema({
  name: 'SalesTarget', tableName: 'sales_targets',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'target_id' },
    targetMonth: { type: 'date', name: 'target_month' },
    revenueTarget: { type: 'decimal', precision: 14, scale: 2, name: 'revenue_target' },
    profitTarget: { type: 'decimal', precision: 14, scale: 2, nullable: true, name: 'profit_target' },
    unitsTarget: { type: Number, nullable: true, name: 'units_target' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    region: { type: 'many-to-one', target: 'Region', joinColumn: { name: 'region_id' }, nullable: false, onDelete: 'CASCADE' },
    representative: { type: 'many-to-one', target: 'SalesRepresentative', joinColumn: { name: 'rep_id' }, nullable: true, onDelete: 'CASCADE' },
  },
});

export const DataImport = new EntitySchema({
  name: 'DataImport', tableName: 'data_imports',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'import_id' },
    fileName: { type: String, length: 255, name: 'file_name' },
    datasetType: { type: String, length: 100, nullable: true, name: 'dataset_type' },
    sourceType: { type: String, length: 50, nullable: true, name: 'source_type' },
    uploadedAt: { type: 'timestamp', createDate: true, name: 'uploaded_at' },
    completedAt: { type: 'timestamp', nullable: true, name: 'completed_at' },
    recordsReceived: { type: Number, default: 0, name: 'records_received' },
    recordsImported: { type: Number, default: 0, name: 'records_imported' },
    recordsRejected: { type: Number, default: 0, name: 'records_rejected' },
    status: { type: String, length: 30, default: 'Pending' },
    errorMessage: { type: 'text', nullable: true, name: 'error_message' },
  },
  relations: {
    uploadedBy: { type: 'many-to-one', target: 'User', joinColumn: { name: 'uploaded_by' }, nullable: true, onDelete: 'SET NULL' },
  },
});

export const EtlJob = new EntitySchema({
  name: 'EtlJob', tableName: 'etl_jobs',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'etl_id' },
    startedAt: { type: 'timestamp', createDate: true, name: 'started_at' },
    completedAt: { type: 'timestamp', nullable: true, name: 'completed_at' },
    status: { type: String, length: 30, default: 'Pending' },
    recordsProcessed: { type: Number, default: 0, name: 'records_processed' },
    recordsSuccessful: { type: Number, default: 0, name: 'records_successful' },
    recordsFailed: { type: Number, default: 0, name: 'records_failed' },
    errorMessage: { type: 'text', nullable: true, name: 'error_message' },
  },
  relations: {
    dataImport: { type: 'many-to-one', target: 'DataImport', joinColumn: { name: 'import_id' }, nullable: true, onDelete: 'SET NULL' },
  },
});

export const DataQualityIssue = new EntitySchema({
  name: 'DataQualityIssue', tableName: 'data_quality_issues',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'issue_id' },
    dataset: { type: String, length: 100 },
    recordId: { type: String, length: 100, nullable: true, name: 'record_id' },
    issueType: { type: String, length: 100, name: 'issue_type' },
    description: { type: 'text', nullable: true },
    severity: { type: String, length: 30, nullable: true },
    status: { type: String, length: 30, default: 'Open' },
    detectedAt: { type: 'timestamp', createDate: true, name: 'detected_at' },
    resolvedAt: { type: 'timestamp', nullable: true, name: 'resolved_at' },
  },
  relations: {
    resolvedBy: { type: 'many-to-one', target: 'User', joinColumn: { name: 'resolved_by' }, nullable: true, onDelete: 'SET NULL' },
  },
});


export const CustomerSegment = new EntitySchema({
  name: 'CustomerSegment', tableName: 'customer_segments',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'segment_id' },
    name: { type: String, length: 100, unique: true, name: 'segment_name' },
    description: { type: 'text', nullable: true },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    members: { type: 'one-to-many', target: 'CustomerSegmentMember', inverseSide: 'segment' },
  },
});

export const CustomerSegmentMember = new EntitySchema({
  name: 'CustomerSegmentMember', tableName: 'customer_segment_members',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'membership_id' },
    assignedAt: { type: 'timestamp', createDate: true, name: 'assigned_at' },
  },
  relations: {
    customer: { type: 'many-to-one', target: 'Customer', inverseSide: 'segmentMemberships', joinColumn: { name: 'customer_id' }, nullable: false, onDelete: 'CASCADE' },
    segment: { type: 'many-to-one', target: 'CustomerSegment', inverseSide: 'members', joinColumn: { name: 'segment_id' }, nullable: false, onDelete: 'CASCADE' },
  },
});

export const PromotionProduct = new EntitySchema({
  name: 'PromotionProduct', tableName: 'promotion_products',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'promotion_product_id' },
  },
  relations: {
    promotion: { type: 'many-to-one', target: 'Promotion', inverseSide: 'productLinks', joinColumn: { name: 'promotion_id' }, nullable: false, onDelete: 'CASCADE' },
    product: { type: 'many-to-one', target: 'Product', inverseSide: 'promotionLinks', joinColumn: { name: 'product_id' }, nullable: false, onDelete: 'CASCADE' },
  },
});

export const PromotionSale = new EntitySchema({
  name: 'PromotionSale', tableName: 'promotion_sales',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'promotion_sale_id' },
    discountGiven: { type: 'decimal', precision: 14, scale: 2, default: 0, name: 'discount_given' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    promotion: { type: 'many-to-one', target: 'Promotion', inverseSide: 'saleLinks', joinColumn: { name: 'promotion_id' }, nullable: false, onDelete: 'CASCADE' },
    order: { type: 'many-to-one', target: 'SalesOrder', joinColumn: { name: 'order_id' }, nullable: false, onDelete: 'CASCADE' },
  },
});

export const AuditLog = new EntitySchema({
  name: 'AuditLog', tableName: 'audit_logs',
  columns: {
    id: { type: 'bigint', primary: true, generated: true, name: 'log_id' },
    action: { type: String, length: 100 },
    tableName: { type: String, length: 100, nullable: true, name: 'table_name' },
    recordId: { type: String, length: 100, nullable: true, name: 'record_id' },
    oldValues: { type: 'jsonb', nullable: true, name: 'old_values' },
    newValues: { type: 'jsonb', nullable: true, name: 'new_values' },
    ipAddress: { type: String, length: 100, nullable: true, name: 'ip_address' },
    createdAt: { type: 'timestamp', createDate: true, name: 'created_at' },
  },
  relations: {
    user: { type: 'many-to-one', target: 'User', joinColumn: { name: 'user_id' }, nullable: true, onDelete: 'SET NULL' },
  },
});

export const SystemSetting = new EntitySchema({
  name: 'SystemSetting', tableName: 'system_settings',
  columns: {
    id: { type: Number, primary: true, generated: true, name: 'setting_id' },
    key: { type: String, length: 100, unique: true, name: 'setting_key' },
    value: { type: 'text', nullable: true, name: 'setting_value' },
    description: { type: 'text', nullable: true },
    updatedAt: { type: 'timestamp', updateDate: true, name: 'updated_at' },
  },
  relations: {
    updatedBy: { type: 'many-to-one', target: 'User', joinColumn: { name: 'updated_by' }, nullable: true, onDelete: 'SET NULL' },
  },
});

export const entities = [Role, Region, Category, User, Product, Customer, SalesRepresentative, Promotion, PromotionProduct, PromotionSale, SalesOrder, SalesOrderItem, SalesTarget, CustomerSegment, CustomerSegmentMember, DataImport, EtlJob, DataQualityIssue, AuditLog, SystemSetting];
