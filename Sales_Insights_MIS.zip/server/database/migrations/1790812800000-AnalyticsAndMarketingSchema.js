export class AnalyticsAndMarketingSchema1790812800000 {
  name = 'AnalyticsAndMarketingSchema1790812800000';

  async up(queryRunner) {
    await queryRunner.query(`
      ALTER TABLE customers ADD COLUMN IF NOT EXISTS customer_code VARCHAR(50);
      CREATE UNIQUE INDEX IF NOT EXISTS ux_customers_customer_code ON customers(customer_code) WHERE customer_code IS NOT NULL;

      ALTER TABLE sales_targets ADD COLUMN IF NOT EXISTS profit_target NUMERIC(14,2);

      ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS source_type VARCHAR(50);
      ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP;
      ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS error_message TEXT;

      CREATE TABLE IF NOT EXISTS customer_segments (
        segment_id SERIAL PRIMARY KEY,
        segment_name VARCHAR(100) UNIQUE NOT NULL,
        description TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS customer_segment_members (
        membership_id SERIAL PRIMARY KEY,
        customer_id INTEGER NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
        segment_id INTEGER NOT NULL REFERENCES customer_segments(segment_id) ON DELETE CASCADE,
        assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT ux_customer_segment_members UNIQUE(customer_id, segment_id)
      );

      CREATE TABLE IF NOT EXISTS promotion_products (
        promotion_product_id SERIAL PRIMARY KEY,
        promotion_id INTEGER NOT NULL REFERENCES promotions(promotion_id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
        CONSTRAINT ux_promotion_products UNIQUE(promotion_id, product_id)
      );

      CREATE TABLE IF NOT EXISTS promotion_sales (
        promotion_sale_id SERIAL PRIMARY KEY,
        promotion_id INTEGER NOT NULL REFERENCES promotions(promotion_id) ON DELETE CASCADE,
        order_id INTEGER NOT NULL REFERENCES sales_orders(order_id) ON DELETE CASCADE,
        discount_given NUMERIC(14,2) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT ux_promotion_sales UNIQUE(promotion_id, order_id)
      );

      CREATE INDEX IF NOT EXISTS idx_customer_segment_members_customer ON customer_segment_members(customer_id);
      CREATE INDEX IF NOT EXISTS idx_customer_segment_members_segment ON customer_segment_members(segment_id);
      CREATE INDEX IF NOT EXISTS idx_promotion_products_product ON promotion_products(product_id);
      CREATE INDEX IF NOT EXISTS idx_promotion_sales_order ON promotion_sales(order_id);
      CREATE INDEX IF NOT EXISTS idx_sales_targets_month ON sales_targets(target_month);
      CREATE INDEX IF NOT EXISTS idx_data_imports_status ON data_imports(status);
    `);
  }

  async down(queryRunner) {
    await queryRunner.query(`
      DROP TABLE IF EXISTS promotion_sales CASCADE;
      DROP TABLE IF EXISTS promotion_products CASCADE;
      DROP TABLE IF EXISTS customer_segment_members CASCADE;
      DROP TABLE IF EXISTS customer_segments CASCADE;
      ALTER TABLE data_imports DROP COLUMN IF EXISTS error_message;
      ALTER TABLE data_imports DROP COLUMN IF EXISTS completed_at;
      ALTER TABLE data_imports DROP COLUMN IF EXISTS source_type;
      ALTER TABLE sales_targets DROP COLUMN IF EXISTS profit_target;
      ALTER TABLE customers DROP COLUMN IF EXISTS customer_code;
    `);
  }
}
