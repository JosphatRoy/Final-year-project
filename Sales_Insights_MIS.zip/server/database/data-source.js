import "reflect-metadata";
import "dotenv/config";
import { DataSource } from "typeorm";
import { entities } from "./entities/index.js";
import { InitialSchema1789891200000 } from "./migrations/1789891200000-InitialSchema.js";
import { AnalyticsAndMarketingSchema1790812800000 } from "./migrations/1790812800000-AnalyticsAndMarketingSchema.js";

const sslEnabled = String(process.env.DB_SSL || "false").toLowerCase() === "true";
const dbUser = process.env.DB_USER || process.env.DB_USERNAME || "salesinsights";
const dbName = process.env.DB_NAME || process.env.DB_DATABASE || "sales_insights_mis";

export const AppDataSource = new DataSource({
  type: "postgres",
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 5432),
  username: dbUser,
  password: process.env.DB_PASSWORD || "salesinsights_password",
  database: dbName,
  ssl: sslEnabled ? { rejectUnauthorized: false } : false,
  synchronize: false,
  logging: String(process.env.DB_LOGGING || "false").toLowerCase() === "true",
  entities,
  migrations: [InitialSchema1789891200000, AnalyticsAndMarketingSchema1790812800000],
  migrationsTableName: "typeorm_migrations"
});

export async function initializeDatabase() {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  await AppDataSource.runMigrations();
  return AppDataSource;
}
