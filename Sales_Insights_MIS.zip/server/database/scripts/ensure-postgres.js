import "dotenv/config";
import { spawnSync } from "node:child_process";
import pg from "pg";

const { Client } = pg;
const host = process.env.DB_HOST || "127.0.0.1";
const port = Number(process.env.DB_PORT || 5432);
const user = process.env.DB_USER || process.env.DB_USERNAME || "salesinsights";
const password = process.env.DB_PASSWORD || "salesinsights_password";
const database = process.env.DB_NAME || process.env.DB_DATABASE || "sales_insights_mis";

async function testDatabase() {
  const client = new Client({ host, port, user, password, database, connectionTimeoutMillis: 1500 });
  try {
    await client.connect();
    await client.query("SELECT 1");
    return { ok: true };
  } catch (error) {
    return { ok: false, error };
  } finally {
    await client.end().catch(() => {});
  }
}

let result = await testDatabase();
if (result.ok) {
  console.log(`[database] PostgreSQL is ready at ${host}:${port}/${database}.`);
  process.exit(0);
}

const refused = result.error?.code === "ECONNREFUSED";
if (!refused) {
  console.error("\n[database] PostgreSQL is reachable, but the configured database login failed.");
  console.error(`Host: ${host}:${port}  Database: ${database}  User: ${user}`);
  console.error(result.error?.message || result.error);
  console.error("Update .env to match your local PostgreSQL account, or stop the local PostgreSQL service and use the included Docker database.\n");
  process.exit(1);
}

if (!["localhost", "127.0.0.1", "::1"].includes(host)) {
  console.error(`[database] Cannot reach PostgreSQL at ${host}:${port}. Check .env/network connectivity.`);
  process.exit(1);
}

const dockerArgs = ["compose", "version"];
const dockerCheck = spawnSync("docker", dockerArgs, { stdio: "ignore", shell: process.platform === "win32" });
if (dockerCheck.status !== 0) {
  console.error(`\n[database] PostgreSQL is not reachable at ${host}:${port}.`);
  console.error("Install/start PostgreSQL locally OR install/start Docker Desktop.");
  console.error("With Docker Desktop running, npm run dev automatically starts the included PostgreSQL 16 container.\n");
  process.exit(1);
}

console.log("[database] Starting PostgreSQL with Docker Compose...");
const up = spawnSync("docker", ["compose", "up", "-d", "postgres"], {
  stdio: "inherit",
  shell: process.platform === "win32"
});
if (up.status !== 0) process.exit(up.status || 1);

for (let i = 0; i < 40; i++) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  result = await testDatabase();
  if (result.ok) {
    console.log(`[database] PostgreSQL is ready at ${host}:${port}/${database}.`);
    process.exit(0);
  }
}

console.error("[database] PostgreSQL did not become ready in time. Run: docker compose logs postgres");
process.exit(1);
