import "dotenv/config";
import { AppDataSource } from "../data-source.js";
import { seedDatabase } from "../services/seed.js";

if (String(process.env.ALLOW_DB_RESET || "").toLowerCase() !== "true") {
  console.error("Refusing to reset the database. Set ALLOW_DB_RESET=true to continue.");
  process.exit(1);
}

try {
  await AppDataSource.initialize();
  await AppDataSource.dropDatabase();
  await AppDataSource.runMigrations();
  await seedDatabase();
  console.log("Database reset and reseeded.");
} finally {
  if (AppDataSource.isInitialized) await AppDataSource.destroy();
}
