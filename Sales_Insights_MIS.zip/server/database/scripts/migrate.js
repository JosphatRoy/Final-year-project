import { initializeDatabase, AppDataSource } from "../data-source.js";

try {
  await initializeDatabase();
  console.log("Database migrations are up to date.");
} finally {
  if (AppDataSource.isInitialized) await AppDataSource.destroy();
}
