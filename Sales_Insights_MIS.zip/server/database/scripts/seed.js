import { initializeDatabase, AppDataSource } from "../data-source.js";
import { seedDatabase } from "../services/seed.js";

try {
  await initializeDatabase();
  await seedDatabase();
  console.log("Database seed completed.");
} finally {
  if (AppDataSource.isInitialized) await AppDataSource.destroy();
}
