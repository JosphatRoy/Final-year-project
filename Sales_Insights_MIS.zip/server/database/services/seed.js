import bcrypt from "bcryptjs";
import { AppDataSource } from "../data-source.js";
import { ensureCategory, ensureRegion, ensureRepresentative } from "../../services/lookups.js";

const users = [
  ["System Administrator", "admin@company.com", "admin123", "admin", null, null],
  ["Executive Manager", "executive@company.com", "executive123", "executive", null, null],
  ["Nairobi Regional Manager", "regional@company.com", "regional123", "regional_manager", "Nairobi", 50000],
  ["Marketing Analyst", "marketing@company.com", "marketing123", "marketing", null, null],
  ["Data BI Analyst", "analyst@company.com", "analyst123", "analyst", null, null]
];

const products = [
  ["Fresh Milk 500ml", "Dairy", "DAR-001", 85, 55, 420],
  ["Fruit Juice 1L", "Beverages", "BEV-014", 220, 142, 185],
  ["Wheat Biscuits 250g", "Snacks", "SNK-022", 160, 98, 98],
  ["Laundry Soap 1kg", "Home Care", "HOM-031", 310, 205, 65],
  ["Cooking Oil 2L", "Food", "FOD-045", 640, 455, 140]
];

const customers = [
  ["Eastmart Supermarket", "0712 000 101", "orders@eastmart.co.ke", "Nairobi", "Retailer"],
  ["Lakeview Wholesalers", "0712 000 102", "buying@lakeview.co.ke", "Kisumu", "Wholesaler"],
  ["Coast Choice Stores", "0712 000 103", "procurement@coastchoice.co.ke", "Mombasa", "Retailer"],
  ["Rift Valley Distributors", "0712 000 104", "sales@rvd.co.ke", "Nakuru", "Distributor"],
  ["Metro Value Stores", "0712 000 105", "buying@metrovalue.co.ke", "Nairobi", "Retailer"]
];

const sales = [
  ["2026-09-02", "Eastmart Supermarket", "Cooking Oil 2L", 20, 640, "James Kariuki"],
  ["2026-09-04", "Lakeview Wholesalers", "Fresh Milk 500ml", 120, 85, "Mercy Achieng"],
  ["2026-09-06", "Coast Choice Stores", "Fruit Juice 1L", 45, 220, "Ahmed Noor"],
  ["2026-09-08", "Rift Valley Distributors", "Laundry Soap 1kg", 30, 310, "Faith Wanjiru"],
  ["2026-09-10", "Eastmart Supermarket", "Wheat Biscuits 250g", 60, 160, "James Kariuki"],
  ["2026-09-12", "Lakeview Wholesalers", "Cooking Oil 2L", 12, 640, "Mercy Achieng"],
  ["2026-09-15", "Coast Choice Stores", "Fresh Milk 500ml", 90, 85, "Ahmed Noor"],
  ["2026-09-17", "Rift Valley Distributors", "Fruit Juice 1L", 35, 220, "Faith Wanjiru"],
  ["2026-09-18", "Metro Value Stores", "Fresh Milk 500ml", 80, 85, "Lucy Njeri"],
  ["2026-09-19", "Metro Value Stores", "Fruit Juice 1L", 25, 220, "Lucy Njeri"]
];

export async function seedDatabase() {
  const roleRepo = AppDataSource.getRepository("Role");
  const userRepo = AppDataSource.getRepository("User");
  const productRepo = AppDataSource.getRepository("Product");
  const customerRepo = AppDataSource.getRepository("Customer");
  const orderRepo = AppDataSource.getRepository("SalesOrder");
  const itemRepo = AppDataSource.getRepository("SalesOrderItem");

  const roleDefs = [
    ["admin", "System Administrator / IT Administrator", "Controls and maintains the entire MIS"],
    ["executive", "Executive / Senior Management", "Strategic, company-wide read-only analysis"],
    ["regional_manager", "Regional Sales Manager", "Operational sales management for an assigned region"],
    ["marketing", "Marketing Analyst / Marketing Manager", "Customer, product and market analysis"],
    ["analyst", "Data / BI Analyst", "Data quality, ETL and deeper business analysis"]
  ];

  for (const [code, name, description] of roleDefs) {
    let row = await roleRepo.findOne({ where: { code } });
    if (!row) row = roleRepo.create({ code, name, description });
    else Object.assign(row, { name, description });
    await roleRepo.save(row);
  }

  for (const region of ["Nairobi", "Kisumu", "Mombasa", "Nakuru"]) await ensureRegion(region);

  // Keep the packaged demo accounts usable on every development startup.
  for (const [name, email, password, roleCode, regionName, target] of users) {
    const role = await roleRepo.findOne({ where: { code: roleCode } });
    const region = regionName ? await ensureRegion(regionName) : null;
    let row = await userRepo.findOne({ where: { email }, relations: { role: true, region: true } });
    if (!row) {
      row = userRepo.create({ name, email, passwordHash: await bcrypt.hash(password, 12), role, region, target, isActive: true });
    } else {
      const passwordMatches = await bcrypt.compare(password, row.passwordHash || "").catch(() => false);
      Object.assign(row, { name, role, region, target, isActive: true });
      if (!passwordMatches) row.passwordHash = await bcrypt.hash(password, 12);
    }
    await userRepo.save(row);
  }

  for (const [name, categoryName, sku, price, cost, stock] of products) {
    let row = await productRepo.findOne({ where: { sku } });
    if (!row) {
      const category = await ensureCategory(categoryName);
      await productRepo.save(productRepo.create({ name, category, sku, sellingPrice: price, costPrice: cost, stock, status: "Active" }));
    }
  }

  for (let customerIndex = 0; customerIndex < customers.length; customerIndex++) {
    const [name, phone, email, regionName, segment] = customers[customerIndex];
    let row = await customerRepo.findOne({ where: { email }, relations: { region: true } });
    const region = await ensureRegion(regionName);
    const code = `CUS-${String(customerIndex + 1).padStart(4, "0")}`;
    if (!row) {
      row = customerRepo.create({ code, name, phone, email, region, segment, status: "Active" });
    } else {
      Object.assign(row, { code: row.code || code, region, segment, status: "Active" });
    }
    await customerRepo.save(row);
  }

  if ((await orderRepo.count()) === 0) {
    const admin = await userRepo.findOne({ where: { email: "admin@company.com" } });
    for (let index = 0; index < sales.length; index++) {
      const [date, customerName, productName, quantity, unitPrice, salesperson] = sales[index];
      const customer = await customerRepo.findOne({ where: { name: customerName }, relations: { region: true } });
      const product = await productRepo.findOne({ where: { name: productName }, relations: { category: true } });
      const representative = await ensureRepresentative(salesperson, customer.region);
      const unitCost = Number(product.costPrice);
      const totalAmount = quantity * unitPrice;
      const totalCost = quantity * unitCost;
      const order = await orderRepo.save(orderRepo.create({
        invoiceNumber: `SEED-${String(index + 1).padStart(4, "0")}`,
        saleDate: date,
        customer,
        representative,
        region: customer.region,
        totalAmount,
        totalCost,
        profit: totalAmount - totalCost,
        createdBy: admin
      }));
      await itemRepo.save(itemRepo.create({
        order,
        product,
        quantity,
        unitPrice,
        unitCost,
        discountAmount: 0,
        lineTotal: totalAmount,
        costAmount: totalCost,
        profit: totalAmount - totalCost
      }));
    }
  }

  // Marketing/customer segmentation structures used by the Marketing dashboard and SQL reports.
  const segmentRepo = AppDataSource.getRepository("CustomerSegment");
  const membershipRepo = AppDataSource.getRepository("CustomerSegmentMember");
  const segmentDefinitions = [
    ["Retail", "Retail outlets and stores"],
    ["Wholesale", "Wholesale customers buying in larger volumes"],
    ["Distributor", "Regional distribution partners"],
    ["High Value", "Customers selected for high-value analysis"]
  ];
  for (const [name, description] of segmentDefinitions) {
    let segment = await segmentRepo.findOne({ where: { name } });
    if (!segment) segment = await segmentRepo.save(segmentRepo.create({ name, description }));
  }
  for (const [, , email, , legacySegment] of customers) {
    const customer = await customerRepo.findOne({ where: { email } });
    const mappedName = legacySegment === "Retailer" ? "Retail" : legacySegment;
    const segment = await segmentRepo.findOne({ where: { name: mappedName } });
    if (customer && segment) {
      const exists = await membershipRepo.findOne({ where: { customer: { id: customer.id }, segment: { id: segment.id } }, relations: { customer: true, segment: true } });
      if (!exists) await membershipRepo.save(membershipRepo.create({ customer, segment }));
    }
  }

  const promotionRepo = AppDataSource.getRepository("Promotion");
  const promotionProductRepo = AppDataSource.getRepository("PromotionProduct");
  let promotion = await promotionRepo.findOne({ where: { name: "October Growth Campaign" } });
  if (!promotion) {
    promotion = await promotionRepo.save(promotionRepo.create({
      name: "October Growth Campaign",
      startDate: "2026-10-01",
      endDate: "2026-10-31",
      discountPercentage: 5,
      budget: 250000,
      description: "Demo promotion for product and campaign analytics.",
      status: "Active"
    }));
  }
  for (const sku of ["BEV-014", "FOD-045"]) {
    const product = await productRepo.findOne({ where: { sku } });
    if (!product) continue;
    const linked = await promotionProductRepo.findOne({ where: { promotion: { id: promotion.id }, product: { id: product.id } }, relations: { promotion: true, product: true } });
    if (!linked) await promotionProductRepo.save(promotionProductRepo.create({ promotion, product }));
  }

  const targetRepo = AppDataSource.getRepository("SalesTarget");
  for (const regionName of ["Nairobi", "Kisumu", "Mombasa", "Nakuru"]) {
    const region = await ensureRegion(regionName);
    const exists = await targetRepo.findOne({ where: { region: { id: region.id }, targetMonth: "2026-10-01" }, relations: { region: true } });
    if (!exists) await targetRepo.save(targetRepo.create({ region, targetMonth: "2026-10-01", revenueTarget: 500000, profitTarget: 150000, unitsTarget: 1500 }));
  }

  const settingRepo = AppDataSource.getRepository("SystemSetting");
  for (const [key, value, description] of [
    ["company_name", "Sales Insights Consumer Goods Company", "Displayed company name"],
    ["currency", "KES", "Reporting currency"],
    ["financial_year_start", "01-01", "Month-day financial year start"]
  ]) {
    let row = await settingRepo.findOne({ where: { key } });
    if (!row) await settingRepo.save(settingRepo.create({ key, value, description }));
  }
}
