CREATE TABLE IF NOT EXISTS roles (
  role_id SERIAL PRIMARY KEY,
  role_code VARCHAR(50) UNIQUE NOT NULL,
  role_name VARCHAR(120) UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS regions (
  region_id SERIAL PRIMARY KEY,
  region_name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
  category_id SERIAL PRIMARY KEY,
  category_name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS users (
  user_id SERIAL PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role_id INTEGER NOT NULL REFERENCES roles(role_id) ON DELETE RESTRICT,
  region_id INTEGER REFERENCES regions(region_id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sales_target NUMERIC(14,2),
  last_login TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  product_id SERIAL PRIMARY KEY,
  sku VARCHAR(50) UNIQUE NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  category_id INTEGER NOT NULL REFERENCES categories(category_id) ON DELETE RESTRICT,
  cost_price NUMERIC(12,2) NOT NULL,
  selling_price NUMERIC(12,2) NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_product_prices CHECK (cost_price >= 0 AND selling_price >= 0),
  CONSTRAINT chk_product_stock CHECK (stock >= 0)
);

CREATE TABLE IF NOT EXISTS customers (
  customer_id SERIAL PRIMARY KEY,
  customer_name VARCHAR(150) NOT NULL,
  segment VARCHAR(50),
  region_id INTEGER REFERENCES regions(region_id) ON DELETE SET NULL,
  city VARCHAR(100),
  phone VARCHAR(50),
  email VARCHAR(150),
  status VARCHAR(30) NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales_representatives (
  rep_id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
  employee_number VARCHAR(50) UNIQUE,
  rep_name VARCHAR(150) NOT NULL,
  region_id INTEGER NOT NULL REFERENCES regions(region_id) ON DELETE RESTRICT,
  status VARCHAR(30) NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS promotions (
  promotion_id SERIAL PRIMARY KEY,
  promotion_name VARCHAR(150) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  discount_percentage NUMERIC(5,2),
  budget NUMERIC(14,2),
  description TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'Planned',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_promotion_dates CHECK (end_date >= start_date)
);

CREATE TABLE IF NOT EXISTS sales_orders (
  order_id SERIAL PRIMARY KEY,
  invoice_number VARCHAR(50) UNIQUE NOT NULL,
  customer_id INTEGER NOT NULL REFERENCES customers(customer_id) ON DELETE RESTRICT,
  rep_id INTEGER REFERENCES sales_representatives(rep_id) ON DELETE SET NULL,
  region_id INTEGER NOT NULL REFERENCES regions(region_id) ON DELETE RESTRICT,
  promotion_id INTEGER REFERENCES promotions(promotion_id) ON DELETE SET NULL,
  sale_date DATE NOT NULL,
  total_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  total_cost NUMERIC(14,2) NOT NULL DEFAULT 0,
  profit NUMERIC(14,2) NOT NULL DEFAULT 0,
  payment_status VARCHAR(30) NOT NULL DEFAULT 'Paid',
  created_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales_order_items (
  item_id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES sales_orders(order_id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(product_id) ON DELETE RESTRICT,
  quantity INTEGER NOT NULL,
  unit_price NUMERIC(12,2) NOT NULL,
  unit_cost NUMERIC(12,2) NOT NULL,
  discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  line_total NUMERIC(14,2) NOT NULL,
  cost_amount NUMERIC(14,2) NOT NULL,
  profit NUMERIC(14,2) NOT NULL,
  CONSTRAINT chk_sales_quantity CHECK (quantity > 0),
  CONSTRAINT chk_sales_price CHECK (unit_price >= 0 AND unit_cost >= 0)
);

CREATE TABLE IF NOT EXISTS sales_targets (
  target_id SERIAL PRIMARY KEY,
  region_id INTEGER NOT NULL REFERENCES regions(region_id) ON DELETE CASCADE,
  rep_id INTEGER REFERENCES sales_representatives(rep_id) ON DELETE CASCADE,
  target_month DATE NOT NULL,
  revenue_target NUMERIC(14,2) NOT NULL,
  units_target INTEGER,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS data_imports (
  import_id SERIAL PRIMARY KEY,
  file_name VARCHAR(255) NOT NULL,
  dataset_type VARCHAR(100),
  uploaded_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  records_received INTEGER NOT NULL DEFAULT 0,
  records_imported INTEGER NOT NULL DEFAULT 0,
  records_rejected INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending'
);

CREATE TABLE IF NOT EXISTS etl_jobs (
  etl_id SERIAL PRIMARY KEY,
  import_id INTEGER REFERENCES data_imports(import_id) ON DELETE SET NULL,
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP,
  status VARCHAR(30) NOT NULL DEFAULT 'Pending',
  records_processed INTEGER NOT NULL DEFAULT 0,
  records_successful INTEGER NOT NULL DEFAULT 0,
  records_failed INTEGER NOT NULL DEFAULT 0,
  error_message TEXT
);

CREATE TABLE IF NOT EXISTS data_quality_issues (
  issue_id SERIAL PRIMARY KEY,
  dataset VARCHAR(100) NOT NULL,
  record_id VARCHAR(100),
  issue_type VARCHAR(100) NOT NULL,
  description TEXT,
  severity VARCHAR(30),
  status VARCHAR(30) NOT NULL DEFAULT 'Open',
  detected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at TIMESTAMP,
  resolved_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  log_id BIGSERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  table_name VARCHAR(100),
  record_id VARCHAR(100),
  old_values JSONB,
  new_values JSONB,
  ip_address VARCHAR(100),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_settings (
  setting_id SERIAL PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT,
  description TEXT,
  updated_by INTEGER REFERENCES users(user_id) ON DELETE SET NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_role ON users(role_id);
CREATE INDEX IF NOT EXISTS idx_users_region ON users(region_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_customers_region ON customers(region_id);
CREATE INDEX IF NOT EXISTS idx_sales_orders_date ON sales_orders(sale_date);
CREATE INDEX IF NOT EXISTS idx_sales_orders_region ON sales_orders(region_id);
CREATE INDEX IF NOT EXISTS idx_sales_orders_customer ON sales_orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_sales_items_product ON sales_order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);


-- Extended marketing/analytics schema (migration 1790812800000)
ALTER TABLE customers ADD COLUMN IF NOT EXISTS customer_code VARCHAR(50);
CREATE UNIQUE INDEX IF NOT EXISTS ux_customers_customer_code ON customers(customer_code) WHERE customer_code IS NOT NULL;
ALTER TABLE sales_targets ADD COLUMN IF NOT EXISTS profit_target NUMERIC(14,2);
ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS source_type VARCHAR(50);
ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP;
ALTER TABLE data_imports ADD COLUMN IF NOT EXISTS error_message TEXT;

CREATE TABLE IF NOT EXISTS customer_segments (
  segment_id SERIAL PRIMARY KEY,
  segment_name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS customer_segment_members (
  membership_id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
  segment_id INTEGER NOT NULL REFERENCES customer_segments(segment_id) ON DELETE CASCADE,
  assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT ux_customer_segment_members UNIQUE(customer_id, segment_id)
);

CREATE TABLE IF NOT EXISTS promotion_products (
  promotion_product_id SERIAL PRIMARY KEY,
  promotion_id INTEGER NOT NULL REFERENCES promotions(promotion_id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
  CONSTRAINT ux_promotion_products UNIQUE(promotion_id, product_id)
);

CREATE TABLE IF NOT EXISTS promotion_sales (
  promotion_sale_id SERIAL PRIMARY KEY,
  promotion_id INTEGER NOT NULL REFERENCES promotions(promotion_id) ON DELETE CASCADE,
  order_id INTEGER NOT NULL REFERENCES sales_orders(order_id) ON DELETE CASCADE,
  discount_given NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT ux_promotion_sales UNIQUE(promotion_id, order_id)
);
