import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { AppDataSource } from '../database/data-source.js';
import { authenticate, allowRoles } from '../middleware/auth.js';
import { audit } from '../services/audit.js';
import { customerDto, productDto, saleDto, userDto } from '../services/mappers.js';
import { ensureCategory, ensureRegion, ensureRepresentative } from '../services/lookups.js';

const router = express.Router();
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const orderRelations = {
  customer: true,
  region: true,
  representative: true,
  promotion: true,
  items: { product: { category: true } },
};

async function loadBootstrap(user) {
  const productRepo = AppDataSource.getRepository('Product');
  const customerRepo = AppDataSource.getRepository('Customer');
  const orderRepo = AppDataSource.getRepository('SalesOrder');
  const userRepo = AppDataSource.getRepository('User');

  const products = await productRepo.find({ relations: { category: true }, order: { id: 'ASC' } });
  const customerWhere = user.role === 'regional_manager' && user.regionId ? { region: { id: user.regionId } } : {};
  const orderWhere = user.role === 'regional_manager' && user.regionId ? { region: { id: user.regionId } } : {};

  const customers = await customerRepo.find({ where: customerWhere, relations: { region: true }, order: { id: 'ASC' } });
  const sales = await orderRepo.find({ where: orderWhere, relations: orderRelations, order: { saleDate: 'ASC', id: 'ASC' } });
  const users = user.role === 'admin'
    ? await userRepo.find({ relations: { role: true, region: true }, order: { id: 'ASC' } })
    : [];

  return {
    users: users.map(userDto),
    products: products.map(productDto),
    customers: customers.map(customerDto),
    sales: sales.map(saleDto),
  };
}

router.get('/health', asyncHandler(async (_req, res) => {
  await AppDataSource.query('SELECT 1');
  res.json({ status: 'ok', database: 'connected' });
}));

router.post('/auth/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });

  const repo = AppDataSource.getRepository('User');
  const user = await repo.findOne({
    where: { email: String(email).trim().toLowerCase() },
    relations: { role: true, region: true },
  });
  if (!user || !user.isActive || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ message: 'Invalid credentials or inactive account.' });
  }

  user.lastLogin = new Date();
  await repo.save(user);
  const safeUser = userDto(user);
  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role.code, regionId: user.region?.id || null, region: user.region?.name || null },
    process.env.JWT_SECRET || 'development-secret-change-me',
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' },
  );
  res.json({ token, user: safeUser });
}));

router.use(authenticate);

router.get('/bootstrap', asyncHandler(async (req, res) => {
  res.json(await loadBootstrap(req.user));
}));

router.get('/products', asyncHandler(async (_req, res) => {
  const rows = await AppDataSource.getRepository('Product').find({ relations: { category: true }, order: { id: 'ASC' } });
  res.json(rows.map(productDto));
}));

router.post('/products', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Product');
  const category = await ensureCategory(req.body.category);
  const row = await repo.save(repo.create({
    sku: req.body.sku,
    name: req.body.name,
    category,
    sellingPrice: Number(req.body.price || 0),
    costPrice: Number(req.body.unitCost || 0),
    stock: Number(req.body.stock || 0),
    status: req.body.status || 'Active',
  }));
  const saved = await repo.findOne({ where: { id: row.id }, relations: { category: true } });
  await audit(req, 'CREATE', 'products', row.id, null, productDto(saved));
  res.status(201).json(productDto(saved));
}));

router.put('/products/:id', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Product');
  const row = await repo.findOne({ where: { id: Number(req.params.id) }, relations: { category: true } });
  if (!row) return res.status(404).json({ message: 'Product not found.' });
  const before = productDto(row);
  row.name = req.body.name ?? row.name;
  row.sku = req.body.sku ?? row.sku;
  if (req.body.category) row.category = await ensureCategory(req.body.category);
  if (req.body.price != null) row.sellingPrice = Number(req.body.price);
  if (req.body.unitCost != null) row.costPrice = Number(req.body.unitCost);
  if (req.body.stock != null) row.stock = Number(req.body.stock);
  if (req.body.status) row.status = req.body.status;
  await repo.save(row);
  const saved = await repo.findOne({ where: { id: row.id }, relations: { category: true } });
  await audit(req, 'UPDATE', 'products', row.id, before, productDto(saved));
  res.json(productDto(saved));
}));

router.delete('/products/:id', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Product');
  const row = await repo.findOne({ where: { id: Number(req.params.id) }, relations: { category: true } });
  if (!row) return res.status(404).json({ message: 'Product not found.' });
  const before = productDto(row);
  await repo.remove(row);
  await audit(req, 'DELETE', 'products', req.params.id, before, null);
  res.json({ message: 'Product deleted.' });
}));

router.get('/customers', asyncHandler(async (req, res) => {
  const where = req.user.role === 'regional_manager' && req.user.regionId ? { region: { id: req.user.regionId } } : {};
  const rows = await AppDataSource.getRepository('Customer').find({ where, relations: { region: true }, order: { id: 'ASC' } });
  res.json(rows.map(customerDto));
}));

router.post('/customers', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Customer');
  const region = await ensureRegion(req.body.region);
  let row = await repo.save(repo.create({
    code: req.body.code || null,
    name: req.body.name,
    segment: req.body.type || 'Retailer',
    region,
    phone: req.body.contact || '',
    email: req.body.email || null,
    status: req.body.status || 'Active',
  }));
  if (!row.code) {
    row.code = `CUS-${String(row.id).padStart(6, '0')}`;
    row = await repo.save(row);
  }
  const saved = await repo.findOne({ where: { id: row.id }, relations: { region: true } });
  await audit(req, 'CREATE', 'customers', row.id, null, customerDto(saved));
  res.status(201).json(customerDto(saved));
}));

router.put('/customers/:id', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Customer');
  const row = await repo.findOne({ where: { id: Number(req.params.id) }, relations: { region: true } });
  if (!row) return res.status(404).json({ message: 'Customer not found.' });
  const before = customerDto(row);
  row.name = req.body.name ?? row.name;
  if ('code' in req.body && req.body.code) row.code = String(req.body.code).trim().toUpperCase();
  row.segment = req.body.type ?? row.segment;
  if (req.body.region) row.region = await ensureRegion(req.body.region);
  row.phone = req.body.contact ?? row.phone;
  row.email = req.body.email ?? row.email;
  row.status = req.body.status ?? row.status;
  await repo.save(row);
  const saved = await repo.findOne({ where: { id: row.id }, relations: { region: true } });
  await audit(req, 'UPDATE', 'customers', row.id, before, customerDto(saved));
  res.json(customerDto(saved));
}));

router.delete('/customers/:id', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('Customer');
  const row = await repo.findOne({ where: { id: Number(req.params.id) }, relations: { region: true } });
  if (!row) return res.status(404).json({ message: 'Customer not found.' });
  const before = customerDto(row);
  await repo.remove(row);
  await audit(req, 'DELETE', 'customers', req.params.id, before, null);
  res.json({ message: 'Customer deleted.' });
}));

async function getSaleOrder(id) {
  return AppDataSource.getRepository('SalesOrder').findOne({ where: { id: Number(id) }, relations: orderRelations });
}

async function buildSaleParts(req, existing = null) {
  const productRepo = AppDataSource.getRepository('Product');
  const customerRepo = AppDataSource.getRepository('Customer');
  const product = await productRepo.findOne({ where: { name: req.body.product }, relations: { category: true } });
  const customer = await customerRepo.findOne({ where: { name: req.body.customer }, relations: { region: true } });
  if (!product || !customer) throw Object.assign(new Error('The selected product or customer does not exist.'), { status: 400 });

  let region = customer.region || await ensureRegion(req.body.region || 'Other');
  if (req.user.role === 'regional_manager') {
    if (!req.user.regionId || region.id !== req.user.regionId) {
      throw Object.assign(new Error('Regional managers can only maintain sales for their assigned region.'), { status: 403 });
    }
  } else if (req.body.region) {
    region = await ensureRegion(req.body.region);
  }

  const representative = await ensureRepresentative(req.body.salesperson || req.user.email, region);
  const quantity = Number(req.body.quantity || 0);
  const unitPrice = Number(req.body.unitPrice || product.sellingPrice || 0);
  if (!(quantity > 0) || unitPrice < 0) throw Object.assign(new Error('Quantity and unit price are invalid.'), { status: 400 });
  const unitCost = Number(product.costPrice || 0);
  const totalAmount = quantity * unitPrice;
  const totalCost = quantity * unitCost;
  return { product, customer, region, representative, quantity, unitPrice, unitCost, totalAmount, totalCost, profit: totalAmount - totalCost, existing };
}

router.get('/sales', asyncHandler(async (req, res) => {
  const where = req.user.role === 'regional_manager' && req.user.regionId ? { region: { id: req.user.regionId } } : {};
  const rows = await AppDataSource.getRepository('SalesOrder').find({ where, relations: orderRelations, order: { saleDate: 'ASC', id: 'ASC' } });
  res.json(rows.map(saleDto));
}));

router.post('/sales', allowRoles('admin', 'analyst', 'regional_manager'), asyncHandler(async (req, res) => {
  const parts = await buildSaleParts(req);
  const result = await AppDataSource.transaction(async (manager) => {
    const orderRepo = manager.getRepository('SalesOrder');
    const itemRepo = manager.getRepository('SalesOrderItem');
    const order = await orderRepo.save(orderRepo.create({
      invoiceNumber: `MIS-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      saleDate: req.body.date,
      customer: parts.customer,
      representative: parts.representative,
      region: parts.region,
      totalAmount: parts.totalAmount,
      totalCost: parts.totalCost,
      profit: parts.profit,
      createdBy: { id: req.user.id },
    }));
    await itemRepo.save(itemRepo.create({ order, product: parts.product, quantity: parts.quantity, unitPrice: parts.unitPrice, unitCost: parts.unitCost, discountAmount: 0, lineTotal: parts.totalAmount, costAmount: parts.totalCost, profit: parts.profit }));
    return order.id;
  });
  const saved = await getSaleOrder(result);
  await audit(req, 'CREATE', 'sales_orders', result, null, saleDto(saved));
  res.status(201).json(saleDto(saved));
}));

router.put('/sales/:id', allowRoles('admin', 'analyst', 'regional_manager'), asyncHandler(async (req, res) => {
  const current = await getSaleOrder(req.params.id);
  if (!current) return res.status(404).json({ message: 'Sales record not found.' });
  if (req.user.role === 'regional_manager' && current.region?.id !== req.user.regionId) return res.status(403).json({ message: 'You cannot edit another region.' });
  const before = saleDto(current);
  const parts = await buildSaleParts(req, current);
  await AppDataSource.transaction(async (manager) => {
    const orderRepo = manager.getRepository('SalesOrder');
    const itemRepo = manager.getRepository('SalesOrderItem');
    const order = await orderRepo.findOne({ where: { id: current.id } });
    Object.assign(order, { saleDate: req.body.date, customer: parts.customer, representative: parts.representative, region: parts.region, totalAmount: parts.totalAmount, totalCost: parts.totalCost, profit: parts.profit });
    await orderRepo.save(order);
    let item = await itemRepo.findOne({ where: { order: { id: current.id } }, relations: { order: true } });
    if (!item) item = itemRepo.create({ order });
    Object.assign(item, { product: parts.product, quantity: parts.quantity, unitPrice: parts.unitPrice, unitCost: parts.unitCost, discountAmount: 0, lineTotal: parts.totalAmount, costAmount: parts.totalCost, profit: parts.profit });
    await itemRepo.save(item);
  });
  const saved = await getSaleOrder(current.id);
  await audit(req, 'UPDATE', 'sales_orders', current.id, before, saleDto(saved));
  res.json(saleDto(saved));
}));

router.delete('/sales/:id', allowRoles('admin', 'analyst', 'regional_manager'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('SalesOrder');
  const current = await getSaleOrder(req.params.id);
  if (!current) return res.status(404).json({ message: 'Sales record not found.' });
  if (req.user.role === 'regional_manager' && current.region?.id !== req.user.regionId) return res.status(403).json({ message: 'You cannot delete another region.' });
  const before = saleDto(current);
  await repo.remove(current);
  await audit(req, 'DELETE', 'sales_orders', req.params.id, before, null);
  res.json({ message: 'Sales record deleted.' });
}));

router.get('/users', allowRoles('admin'), asyncHandler(async (_req, res) => {
  const rows = await AppDataSource.getRepository('User').find({ relations: { role: true, region: true }, order: { id: 'ASC' } });
  res.json(rows.map(userDto));
}));

router.post('/users', allowRoles('admin'), asyncHandler(async (req, res) => {
  const userRepo = AppDataSource.getRepository('User');
  const role = await AppDataSource.getRepository('Role').findOne({ where: { code: req.body.role } });
  if (!role) return res.status(400).json({ message: 'Invalid role.' });
  const region = req.body.region ? await ensureRegion(req.body.region) : null;
  const password = String(req.body.password || 'ChangeMe123!');
  const row = await userRepo.save(userRepo.create({ name: req.body.name, email: String(req.body.email).toLowerCase(), passwordHash: await bcrypt.hash(password, 12), role, region, target: req.body.target || null, isActive: req.body.status !== 'Inactive' }));
  const saved = await userRepo.findOne({ where: { id: row.id }, relations: { role: true, region: true } });
  await audit(req, 'CREATE', 'users', row.id, null, userDto(saved));
  res.status(201).json(userDto(saved));
}));

router.put('/users/:id', allowRoles('admin'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('User');
  const row = await repo.findOne({ where: { id: Number(req.params.id) }, relations: { role: true, region: true } });
  if (!row) return res.status(404).json({ message: 'User not found.' });
  const before = userDto(row);
  row.name = req.body.name ?? row.name;
  row.email = req.body.email ? String(req.body.email).toLowerCase() : row.email;
  if (req.body.role) {
    const role = await AppDataSource.getRepository('Role').findOne({ where: { code: req.body.role } });
    if (!role) return res.status(400).json({ message: 'Invalid role.' });
    row.role = role;
  }
  if ('region' in req.body) row.region = req.body.region ? await ensureRegion(req.body.region) : null;
  if ('target' in req.body) row.target = req.body.target || null;
  if (req.body.status) row.isActive = req.body.status !== 'Inactive';
  if (req.body.password) row.passwordHash = await bcrypt.hash(String(req.body.password), 12);
  await repo.save(row);
  const saved = await repo.findOne({ where: { id: row.id }, relations: { role: true, region: true } });
  await audit(req, 'UPDATE', 'users', row.id, before, userDto(saved));
  res.json(userDto(saved));
}));

router.delete('/users/:id', allowRoles('admin'), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ message: 'You cannot delete your own signed-in account.' });
  const repo = AppDataSource.getRepository('User');
  const row = await repo.findOne({ where: { id }, relations: { role: true, region: true } });
  if (!row) return res.status(404).json({ message: 'User not found.' });
  const before = userDto(row);
  await repo.remove(row);
  await audit(req, 'DELETE', 'users', id, before, null);
  res.json({ message: 'User deleted.' });
}));

router.get('/reports/revenue-by-region', asyncHandler(async (req, res) => {
  const qb = AppDataSource.getRepository('SalesOrder').createQueryBuilder('sale')
    .leftJoin('sale.region', 'region')
    .select('region.region_name', 'region')
    .addSelect('SUM(sale.total_amount)', 'revenue')
    .addSelect('SUM(sale.profit)', 'profit')
    .groupBy('region.region_name')
    .orderBy('SUM(sale.total_amount)', 'DESC');
  if (req.user.role === 'regional_manager' && req.user.regionId) qb.where('region.region_id = :regionId', { regionId: req.user.regionId });
  res.json(await qb.getRawMany());
}));

router.post('/bi/import-log', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const repo = AppDataSource.getRepository('DataImport');
  const row = await repo.save(repo.create({
    fileName: req.body.fileName || 'browser-import.csv',
    datasetType: req.body.datasetType || 'unknown',
    sourceType: req.body.sourceType || 'CSV/Excel',
    uploadedBy: { id: req.user.id },
    recordsReceived: Number(req.body.recordsReceived || 0),
    recordsImported: Number(req.body.recordsImported || 0),
    recordsRejected: Number(req.body.recordsRejected || 0),
    status: req.body.status || 'Completed',
    completedAt: (req.body.status || 'Completed') === 'Completed' ? new Date() : null,
    errorMessage: req.body.errorMessage || null,
  }));
  res.status(201).json({ id: row.id, status: row.status });
}));

router.post('/bi/etl', allowRoles('admin', 'analyst'), asyncHandler(async (req, res) => {
  const etlRepo = AppDataSource.getRepository('EtlJob');
  const job = await etlRepo.save(etlRepo.create({ status: 'Running' }));
  try {
    const result = await AppDataSource.transaction(async (manager) => {
      const customers = await manager.getRepository('Customer').find();
      const products = await manager.getRepository('Product').find();
      let processed = 0;
      for (const c of customers) {
        c.name = c.name.trim();
        c.email = c.email?.trim().toLowerCase() || null;
        c.phone = c.phone?.trim() || null;
        await manager.getRepository('Customer').save(c); processed++;
      }
      for (const p of products) {
        p.name = p.name.trim();
        p.sku = p.sku.trim().toUpperCase();
        await manager.getRepository('Product').save(p); processed++;
      }
      return processed;
    });
    job.status = 'Completed'; job.completedAt = new Date(); job.recordsProcessed = result; job.recordsSuccessful = result; job.recordsFailed = 0;
    await etlRepo.save(job);
    await audit(req, 'RUN_ETL', 'etl_jobs', job.id, null, { recordsProcessed: result });
    res.json({ id: job.id, status: job.status, recordsProcessed: result });
  } catch (error) {
    job.status = 'Failed'; job.completedAt = new Date(); job.errorMessage = error.message;
    await etlRepo.save(job);
    throw error;
  }
}));

router.get('/bi/quality', allowRoles('admin', 'analyst'), asyncHandler(async (_req, res) => {
  const [duplicateSkus, duplicateEmails, invalidSales, missingSales] = await Promise.all([
    AppDataSource.query(`SELECT COUNT(*)::int AS count FROM (SELECT sku FROM products GROUP BY sku HAVING COUNT(*) > 1) x`),
    AppDataSource.query(`SELECT COUNT(*)::int AS count FROM (SELECT LOWER(email) FROM customers WHERE email IS NOT NULL GROUP BY LOWER(email) HAVING COUNT(*) > 1) x`),
    AppDataSource.query(`SELECT COUNT(*)::int AS count FROM sales_order_items WHERE quantity <= 0 OR unit_price < 0`),
    AppDataSource.query(`SELECT COUNT(*)::int AS count FROM sales_orders WHERE sale_date IS NULL OR customer_id IS NULL OR region_id IS NULL`),
  ]);
  res.json({ duplicateSkus: duplicateSkus[0].count, duplicateEmails: duplicateEmails[0].count, invalidSales: invalidSales[0].count, missingSales: missingSales[0].count });
}));


// -----------------------------------------------------------------------------
// SQL-backed analytics and marketing reference data.
// These endpoints deliberately use PostgreSQL SQL for reporting workloads while
// CRUD and relationships remain managed by TypeORM repositories/entities.
// -----------------------------------------------------------------------------
router.get('/analytics/overview', asyncHandler(async (req, res) => {
  const regional = req.user.role === 'regional_manager' && req.user.regionId;
  const regionFilter = regional ? 'WHERE o.region_id = $1' : '';
  const itemRegionFilter = regional ? 'WHERE so.region_id = $1' : '';
  const params = regional ? [req.user.regionId] : [];
  const rows = await AppDataSource.query(`
    SELECT
      COUNT(DISTINCT o.order_id)::int AS orders,
      COUNT(DISTINCT o.customer_id)::int AS customers,
      COALESCE(SUM(o.total_amount), 0)::numeric AS revenue,
      COALESCE(SUM(o.profit), 0)::numeric AS profit,
      COALESCE((
        SELECT SUM(si.quantity)::int
        FROM sales_order_items si
        JOIN sales_orders so ON so.order_id = si.order_id
        ${itemRegionFilter}
      ), 0)::int AS units_sold
    FROM sales_orders o
    ${regionFilter}
  `, params);
  res.json(rows[0]);
}));

router.get('/analytics/regions', asyncHandler(async (req, res) => {
  const regionFilter = req.user.role === 'regional_manager' && req.user.regionId
    ? 'WHERE r.region_id = $1'
    : '';
  const params = regionFilter ? [req.user.regionId] : [];
  const rows = await AppDataSource.query(`
    WITH current_targets AS (
      SELECT region_id,
             SUM(revenue_target) AS revenue_target,
             SUM(COALESCE(profit_target, 0)) AS profit_target
      FROM sales_targets
      WHERE DATE_TRUNC('month', target_month) = DATE_TRUNC('month', CURRENT_DATE)
      GROUP BY region_id
    )
    SELECT r.region_id AS id,
           r.region_name AS region,
           COUNT(DISTINCT o.order_id)::int AS orders,
           COALESCE(SUM(o.total_amount), 0)::numeric AS revenue,
           COALESCE(SUM(o.profit), 0)::numeric AS profit,
           COALESCE(t.revenue_target, 0)::numeric AS revenue_target,
           COALESCE(t.profit_target, 0)::numeric AS profit_target
    FROM regions r
    LEFT JOIN sales_orders o ON o.region_id = r.region_id
    LEFT JOIN current_targets t ON t.region_id = r.region_id
    ${regionFilter}
    GROUP BY r.region_id, r.region_name, t.revenue_target, t.profit_target
    ORDER BY revenue DESC, r.region_name
  `, params);
  res.json(rows);
}));

router.get('/analytics/products', asyncHandler(async (req, res) => {
  const regional = req.user.role === 'regional_manager' && req.user.regionId;
  const regionWhere = regional ? 'WHERE o.region_id = $1' : '';
  const params = regional ? [req.user.regionId] : [];
  const rows = await AppDataSource.query(`
    SELECT p.product_id AS id,
           p.sku,
           p.product_name AS product,
           c.category_name AS category,
           COALESCE(SUM(i.quantity), 0)::int AS units_sold,
           COALESCE(SUM(i.line_total), 0)::numeric AS revenue,
           COALESCE(SUM(i.profit), 0)::numeric AS profit
    FROM products p
    JOIN categories c ON c.category_id = p.category_id
    LEFT JOIN sales_order_items i ON i.product_id = p.product_id
    LEFT JOIN sales_orders o ON o.order_id = i.order_id
    ${regionWhere}
    GROUP BY p.product_id, p.sku, p.product_name, c.category_name
    ORDER BY revenue DESC, p.product_name
  `, params);
  res.json(rows);
}));

router.get('/analytics/monthly', asyncHandler(async (req, res) => {
  const regionFilter = req.user.role === 'regional_manager' && req.user.regionId
    ? 'WHERE o.region_id = $1'
    : '';
  const params = regionFilter ? [req.user.regionId] : [];
  const rows = await AppDataSource.query(`
    SELECT TO_CHAR(DATE_TRUNC('month', o.sale_date), 'YYYY-MM') AS month,
           COALESCE(SUM(o.total_amount), 0)::numeric AS revenue,
           COALESCE(SUM(o.profit), 0)::numeric AS profit,
           COUNT(*)::int AS orders
    FROM sales_orders o
    ${regionFilter}
    GROUP BY DATE_TRUNC('month', o.sale_date)
    ORDER BY DATE_TRUNC('month', o.sale_date)
  `, params);
  res.json(rows);
}));

router.get('/analytics/customers', asyncHandler(async (req, res) => {
  const regionFilter = req.user.role === 'regional_manager' && req.user.regionId
    ? 'WHERE c.region_id = $1'
    : '';
  const params = regionFilter ? [req.user.regionId] : [];
  const rows = await AppDataSource.query(`
    SELECT c.customer_id AS id,
           c.customer_code AS code,
           c.customer_name AS customer,
           r.region_name AS region,
           STRING_AGG(DISTINCT cs.segment_name, ', ' ORDER BY cs.segment_name) AS segments,
           COUNT(DISTINCT o.order_id)::int AS orders,
           COALESCE(SUM(o.total_amount), 0)::numeric AS revenue
    FROM customers c
    LEFT JOIN regions r ON r.region_id = c.region_id
    LEFT JOIN customer_segment_members csm ON csm.customer_id = c.customer_id
    LEFT JOIN customer_segments cs ON cs.segment_id = csm.segment_id
    LEFT JOIN sales_orders o ON o.customer_id = c.customer_id
    ${regionFilter}
    GROUP BY c.customer_id, c.customer_code, c.customer_name, r.region_name
    ORDER BY revenue DESC, c.customer_name
  `, params);
  res.json(rows);
}));

router.get('/marketing/segments', allowRoles('admin', 'marketing', 'analyst'), asyncHandler(async (_req, res) => {
  const rows = await AppDataSource.getRepository('CustomerSegment').find({ order: { name: 'ASC' } });
  res.json(rows.map((row) => ({ id: row.id, name: row.name, description: row.description })));
}));

router.get('/marketing/promotions', allowRoles('admin', 'marketing', 'analyst', 'executive'), asyncHandler(async (_req, res) => {
  const rows = await AppDataSource.query(`
    SELECT p.promotion_id AS id,
           p.promotion_name AS name,
           p.start_date AS "startDate",
           p.end_date AS "endDate",
           p.discount_percentage AS "discountPercentage",
           p.budget,
           p.status,
           COUNT(DISTINCT pp.product_id)::int AS "productCount",
           COALESCE(SUM(ps.discount_given), 0)::numeric AS "discountGiven"
    FROM promotions p
    LEFT JOIN promotion_products pp ON pp.promotion_id = p.promotion_id
    LEFT JOIN promotion_sales ps ON ps.promotion_id = p.promotion_id
    GROUP BY p.promotion_id
    ORDER BY p.start_date DESC, p.promotion_id DESC
  `);
  res.json(rows);
}));

export default router;
