import "dotenv/config";
import express from "express";
import cors from "cors";
import { initializeDatabase } from "./database/data-source.js";
import { seedDatabase } from "./database/services/seed.js";
import apiRouter from "./routes/api.js";

const app = express();
const port = Number(process.env.PORT || 4000);

try {
  await initializeDatabase();
  await seedDatabase();
  console.log("Database connected, migrated and seeded.");
} catch (error) {
  console.error("Database startup failed. Check PostgreSQL/Docker and .env values.");
  console.error(error);
  process.exit(1);
}

app.use(cors({ origin: ["http://localhost:5173", "http://127.0.0.1:5173"], credentials: false }));
app.use(express.json({ limit: "5mb" }));
app.use("/api", apiRouter);

app.use((error, _req, res, _next) => {
  console.error(error);
  const status = error.status || (error.code === "23505" ? 409 : error.code === "23503" ? 409 : 500);
  const message = error.code === "23505"
    ? "A record with the same unique value already exists."
    : error.code === "23503"
      ? "This record is already used by another record and cannot be deleted."
      : error.message || "Unexpected server error.";
  res.status(status).json({ message });
});

app.listen(port, () => console.log(`Sales Insights API running on http://localhost:${port}`));
