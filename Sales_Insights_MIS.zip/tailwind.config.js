/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'] },
      boxShadow: {
        soft: '0 12px 36px rgba(15, 23, 42, 0.08)',
        lift: '0 18px 50px rgba(15, 23, 42, 0.12)',
      },
    },
  },
  plugins: [],
};
