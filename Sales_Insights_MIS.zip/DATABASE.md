# Sales Insights MIS Database — TypeORM + PostgreSQL SQL

The system uses **PostgreSQL as the relational SQL database** and **TypeORM as the application data layer**. It intentionally uses both TypeORM and direct SQL rather than treating them as alternatives.

## How the two layers are used

### TypeORM
TypeORM is used for:

- entity mapping and relationships;
- user/product/customer/sales CRUD;
- transactions;
- migration execution;
- database seeding;
- authentication-related data access;
- audit logging and operational records.

### PostgreSQL SQL
Direct parameterized SQL is used for analytical/reporting workloads such as:

- revenue and profit by region;
- product/category performance;
- monthly trends;
- target attainment;
- customer segmentation;
- promotion performance;
- data-quality checks.

This gives the project ORM convenience while preserving the power of SQL for MIS analysis.

## Database structure

Core/security:

- `roles`
- `users`
- `regions`
- `audit_logs`
- `system_settings`

Product/customer master data:

- `categories`
- `products`
- `customers`
- `sales_representatives`
- `customer_segments`
- `customer_segment_members`

Transactions/performance:

- `sales_orders`
- `sales_order_items`
- `sales_targets`

Marketing:

- `promotions`
- `promotion_products`
- `promotion_sales`

Data/BI administration:

- `data_imports`
- `etl_jobs`
- `data_quality_issues`

## Main files

- `server/database/data-source.js` — TypeORM DataSource and migration initialization
- `server/database/entities/index.js` — TypeORM EntitySchema models
- `server/database/migrations/1789891200000-InitialSchema.js` — baseline schema
- `server/database/migrations/1790812800000-AnalyticsAndMarketingSchema.js` — extended MIS schema
- `server/database/services/seed.js` — idempotent demo seed
- `server/database/schema.sql` — SQL schema reference
- `server/database/reporting-queries.sql` — example SQL reports

## Development database defaults

- Database: `sales_insights_mis`
- User: `salesinsights`
- Password: `salesinsights_password`
- Port: `5432`

These defaults are intended for local development only.

## Startup

With Docker Desktop running, the easiest setup is:

```bash
npm install
npm run dev
```

The startup check starts PostgreSQL through Docker when needed. The backend then runs all pending TypeORM migrations, seeds the development data and starts together with the React frontend.

For a local PostgreSQL installation, copy `.env.example` to `.env` and replace the database credentials with your local PostgreSQL account.
